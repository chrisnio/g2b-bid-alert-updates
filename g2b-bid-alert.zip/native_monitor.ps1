$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$script:AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:ConfigPath = Join-Path $script:AppDir "config.json"
$script:StatePath = Join-Path $script:AppDir "native_seen_notices.json"
$script:StarredStatePath = Join-Path $script:AppDir "starred_notices.json"
$script:CrawlerStatusPath = Join-Path $script:AppDir "crawler_status.json"
$script:VersionPath = Join-Path $script:AppDir "VERSION"
$script:AppVersion = if (Test-Path -LiteralPath $script:VersionPath) {
  (Get-Content -LiteralPath $script:VersionPath -Encoding UTF8 -TotalCount 1).Trim()
} else {
  "unknown"
}
$script:ApiUrl = "https://apis.data.go.kr/1230000/ad/BidPublicInfoService/getBidPblancListInfoServcPPSSrch"
$script:PreSpecApiUrl = "https://apis.data.go.kr/1230000/ao/HrcspSsstndrdInfoService/getPublicPrcureThngInfoServcPPSSrch"
$script:TotalNew = 0
$script:RateLimitedUntil = $null
$script:NextCheckAt = $null
$script:CancelRequested = $false
$script:CurrentCrawlerProcess = $null
$script:UpdateInProgress = $false
$script:AvailableUpdateInfo = $null
$script:AvailableUpdateVersion = ""
$script:StarredIds = New-Object "System.Collections.Generic.HashSet[string]"
$script:StarredNotices = @{}

function U([string]$Text) {
  [Text.RegularExpressions.Regex]::Replace($Text, "\\u([0-9a-fA-F]{4})", {
    param($m)
    [char][Convert]::ToInt32($m.Groups[1].Value, 16)
  })
}

$T = @{
  AppTitle = U "\uB098\uB77C\uC7A5\uD130 \uACF5\uACE0 \uBAA8\uB2C8\uD130(Unofficial)"
  Author = U "\uB9CC\uB4E0\uC774 : \uC9C4\uD615\uC6B0"
  KakaoChat = U "\uCE74\uCE74\uC624\uD1A1 \uCC44\uD305"
  Keywords = U "\uAC10\uC2DC \uD0A4\uC6CC\uB4DC"
  KeywordAdd = U "\uD0A4\uC6CC\uB4DC \uCD94\uAC00"
  KeywordAddHint = U "\uCD94\uAC00\uD560 \uD0A4\uC6CC\uB4DC\uB97C \uC785\uB825\uD55C \uB4A4 \uCD94\uAC00\uB97C \uB204\uB974\uC138\uC694."
  KeywordExample = U "\uC608: \uD074\uB77C\uC6B0\uB4DC, \uD544\uB9AC\uD540, ODA"
  KeywordCountWarning = U "\uC8FC\uC758: \uAD8C\uC7A5 \uAC10\uC2DC \uD0A4\uC6CC\uB4DC\uB294 \uCD5C\uB300 10\uAC1C\uC785\uB2C8\uB2E4. \uD0A4\uC6CC\uB4DC\uAC00 \uB9CE\uC544\uC9C8\uC218\uB85D \uAC80\uC0C9 \uC2DC\uAC04\uC774 \uAE38\uC5B4\uC9C0\uBA70, \uAC80\uC0C9 \uC911 \uD504\uB85C\uADF8\uB7A8\uC774 \uC77C\uC2DC\uC801\uC73C\uB85C \uBA48\uCD98 \uAC83\uCC98\uB7FC \uBCF4\uC77C \uC218 \uC788\uC2B5\uB2C8\uB2E4."
  Add = U "\uCD94\uAC00"
  Delete = U "\uC0AD\uC81C"
  Recent = U "\uCD5C\uADFC 3\uC77C \uB2E4\uC2DC \uC870\uD68C"
  Settings = U "\uC124\uC815"
  Help = U "\uCC98\uC74C \uC0AC\uC6A9\uBC95"
  UpdateCheck = U "\uC5C5\uB370\uC774\uD2B8 \uD655\uC778"
  UpdateHistory = U "\uC5C5\uB370\uC774\uD2B8 \uB0B4\uC5ED"
  UpdateAvailable = U "\uC0C8\uB85C\uC6B4 \uBC84\uC804 \uC5C5\uB370\uC774\uD2B8\uAC00 \uC788\uC2B5\uB2C8\uB2E4."
  UpdateNow = U "\uC9C0\uAE08 \uC5C5\uB370\uC774\uD2B8\uD560\uAE4C\uC694?"
  UpdateCurrent = U "\uD604\uC7AC \uCD5C\uC2E0 \uBC84\uC804\uC785\uB2C8\uB2E4."
  UpdateNotConfigured = U "\uC774 \uBC30\uD3EC\uBCF8\uC5D0\uB294 \uC790\uB3D9 \uC5C5\uB370\uC774\uD2B8 \uC8FC\uC18C\uAC00 \uC544\uC9C1 \uC124\uC815\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4."
  UpdateCheckFailed = U "\uC5C5\uB370\uC774\uD2B8 \uC815\uBCF4\uB97C \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4."
  UpdateBadge = U "\uC2E0\uADDC"
  Test = U "\uC54C\uB9BC \uD14C\uC2A4\uD2B8"
  Start = U "\uAC10\uC2DC \uC2DC\uC791"
  Stop = U "\uC815\uC9C0"
  Ready = U "\uB300\uAE30"
  Running = U "\uAC10\uC2DC \uC911"
  Stopped = U "\uC815\uC9C0"
  Stopping = U "\uC911\uC9C0 \uC911"
  Cancelled = U "\uC870\uD68C\uAC00 \uC911\uC9C0\uB418\uC5C8\uC2B5\uB2C8\uB2E4."
  Checking = U "\uC870\uD68C \uC911"
  NoNew = U "\uC2E0\uADDC \uACF5\uACE0 \uC5C6\uC74C"
  New = U "\uC2E0\uADDC"
  ClosingSoon = U "\uB9C8\uAC10\uC784\uBC15"
  Favorite = U "\uAD00\uC2EC"
  Status = U "\uC0C1\uD0DC"
  LastChecked = U "\uB9C8\uC9C0\uB9C9 \uD655\uC778"
  NextCheck = U "\uB2E4\uC74C \uD655\uC778"
  TotalNew = U "\uB204\uC801 \uC2E0\uADDC"
  DataMode = U "\uB370\uC774\uD130 \uBC29\uC2DD"
  ApiMode = U "API"
  CrawlMode = U "\uD06C\uB864\uB9C1"
  ApiThenCrawlMode = U "API \uC6B0\uC120 / \uC9C0\uC5F0\u00B7429\uC2DC \uD06C\uB864\uB9C1"
  Title = U "\uACF5\uACE0\uBA85"
  BidNo = U "\uACF5\uACE0\uBC88\uD638"
  Type = U "\uAD6C\uBD84"
  Agency = U "\uACF5\uACE0\uAE30\uAD00"
  Budget = U "\uC608\uC0B0"
  BudgetEstimate = U "\uC608\uC0B0(\uCD94\uC815\uAC00\uACA9)"
  Posted = U "\uAC8C\uC2DC\uC77C\uC2DC"
  Close = U "\uB9C8\uAC10"
  SearchKeyword = U "\uAC80\uC0C9 \uD0A4\uC6CC\uB4DC"
  Link = U "\uC0C1\uC138 \uB9C1\uD06C"
  ServiceKey = U "\uACF5\uACF5\uB370\uC774\uD130\uD3EC\uD138 \uC778\uC99D\uD0A4"
  GeneralService = U "\uC77C\uBC18\uC6A9\uC5ED"
  TechService = U "\uAE30\uC220\uC6A9\uC5ED"
  Interval = U "\uD655\uC778 \uC8FC\uAE30(\uBD84)"
  Lookback = U "\uCCAB \uC870\uD68C \uBC94\uC704(\uBD84)"
  Overlap = U "\uC911\uBCF5 \uBC29\uC9C0 \uC5EC\uC720(\uBD84)"
  FirstRun = U "\uCCAB \uC2E4\uD589 \uAE30\uC874 \uACF5\uACE0 \uC54C\uB9BC"
  WinNotify = U "Windows \uC54C\uB9BC \uC0AC\uC6A9"
  IncludePreSpec = U "\uC0AC\uC804\uADDC\uACA9 \uD3EC\uD568"
  PreSpec = U "\uC0AC\uC804\uADDC\uACA9"
  ResultSearch = U "\uAC80\uC0C9\uB41C \uACF5\uACE0 \uC7AC\uAC80\uC0C9"
  ResultSearchHint = U "\uACF5\uACE0\uBA85, \uAE30\uAD00, \uD0A4\uC6CC\uB4DC\uC5D0\uC11C \uB2E4\uC2DC \uAC80\uC0C9"
  ResultResetWarning = U "\uACBD\uACE0 : \uD504\uB85C\uADF8\uB7A8 \uC885\uB8CC\uC2DC \uAC80\uC0C9\uB418\uC5C8\uB358 \uACF5\uACE0 \uB9AC\uC2A4\uD2B8\uAC00 \uB9AC\uC14B\uB429\uB2C8\uB2E4. \uAD00\uC2EC\uC5D0 \uBCC4\uD45C\uB97C \uCCB4\uD06C\uD574\uB450\uC2DC\uBA74 \uC7AC\uC2DC\uC791\uC2DC \uC5C6\uC5B4\uC9C0\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4."
  ExcelExport = U "\uC5D1\uC140 \uB0B4\uBCF4\uB0B4\uAE30"
  ExcelNoRows = U "\uB0B4\uBCF4\uB0BC \uACF5\uACE0\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4."
  ExcelSaved = U "\uC5D1\uC140 \uD30C\uC77C\uB85C \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4."
  ExcelFailed = U "\uC5D1\uC140 \uD30C\uC77C\uC744 \uB9CC\uB4E4\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4."
  Clear = U "\uCD08\uAE30\uD654"
  PreSpecApiDenied = U "\uC0AC\uC804\uADDC\uACA9 API \uD65C\uC6A9\uAD8C\uD55C\uC774 \uC5C6\uC5B4 \uC785\uCC30\uACF5\uACE0\uB9CC \uC870\uD68C\uD588\uC2B5\uB2C8\uB2E4."
  PreSpecHelp = U "\uC0AC\uC804\uADDC\uACA9 \uAC80\uC0C9\uC740 \uACF5\uACF5\uB370\uC774\uD130\uD3EC\uD138\uC758 \uB098\uB77C\uC7A5\uD130 \uC0AC\uC804\uADDC\uACA9\uC815\uBCF4\uC11C\uBE44\uC2A4\uB97C \uBCC4\uB3C4\uB85C \uD65C\uC6A9\uC2E0\uCCAD\uD574\uC57C \uD569\uB2C8\uB2E4."
  Theme = U "\uD14C\uB9C8"
  ThemeBlue = U "\uACF5\uACF5 \uBE14\uB8E8"
  ThemeMint = U "\uBBFC\uD2B8 \uD3EC\uCEE4\uC2A4"
  ThemeCharcoal = U "\uCC28\uCF5C \uB098\uC774\uD2B8"
  Save = U "\uC800\uC7A5"
  Cancel = U "\uCDE8\uC18C"
  SettingsTitle = U "\uC124\uC815"
  NoticeAlert = U "\uC2E0\uADDC \uACF5\uACE0 \uC54C\uB9BC"
  EnterKey = U "\uC778\uC99D\uD0A4\uB97C \uC785\uB825\uD558\uC138\uC694."
  EnterKeyword = U "\uAC10\uC2DC \uD0A4\uC6CC\uB4DC\uB97C 1\uAC1C \uC774\uC0C1 \uC785\uB825\uD558\uC138\uC694."
  SelectType = U "\uC6A9\uC5ED \uAD6C\uBD84\uC744 1\uAC1C \uC774\uC0C1 \uC120\uD0DD\uD558\uC138\uC694."
  RateLimited = U "\uACF5\uACF5\uB370\uC774\uD130 API \uC694\uCCAD \uC81C\uD55C\uC785\uB2C8\uB2E4. \uAC10\uC2DC\uB294 \uC720\uC9C0\uD558\uACE0 \uC7A0\uC2DC \uD6C4 \uC790\uB3D9 \uC7AC\uC2DC\uB3C4\uD569\uB2C8\uB2E4. (429)"
  RateLimitedWait = U "\uC694\uCCAD \uC81C\uD55C \uB300\uAE30 \uC911"
  RateLimitHint = U "\uACC4\uC18D \uBC18\uBCF5\uB418\uBA74 \uD0A4\uC6CC\uB4DC \uC218\uB97C \uC904\uC774\uAC70\uB098, \uD655\uC778 \uC8FC\uAE30\uB97C 30\uBD84 \uC774\uC0C1\uC73C\uB85C \uB298\uB824\uBCF4\uC138\uC694."
  Crawling = U "\uD06C\uB864\uB9C1 \uBAA8\uB4DC\uB85C \uC870\uD68C \uC911"
  CrawlingUsed = U "\uD06C\uB864\uB9C1 \uBAA8\uB4DC\uB85C \uC870\uD68C\uD588\uC2B5\uB2C8\uB2E4."
  CrawlingNoMatch = U "\uD06C\uB864\uB9C1\uC740 \uC131\uACF5\uD588\uC9C0\uB9CC \uD604\uC7AC \uD654\uBA74 \uACB0\uACFC\uC5D0\uC11C \uD0A4\uC6CC\uB4DC \uC77C\uCE58 \uC6A9\uC5ED\uC744 \uCC3E\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4."
  CrawlFailed = U "\uD06C\uB864\uB9C1 \uC870\uD68C\uB3C4 \uC2E4\uD328\uD588\uC2B5\uB2C8\uB2E4."
  ApiTimedOut = U "API \uC751\uB2F5\uC774 \uC9C0\uC5F0\uB418\uC5B4 \uD06C\uB864\uB9C1\uB85C \uC804\uD658\uD569\uB2C8\uB2E4."
  TemporaryFailure = U "\uC77C\uC2DC\uC801\uC73C\uB85C \uC870\uD68C\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uAC10\uC2DC\uB97C \uC720\uC9C0\uD558\uACE0 \uB2E4\uC74C \uC8FC\uAE30\uC5D0 \uC790\uB3D9 \uC7AC\uC2DC\uB3C4\uD569\uB2C8\uB2E4."
  WebServiceBoth = U "\uC77C\uBC18/\uAE30\uC220\uC6A9\uC5ED(\uC6F9)"
  WebSuffix = U "(\uC6F9)"
  NowChecking = U "\uD655\uC778 \uC911"
  CrawlIntervalWarning = U "\uD06C\uB864\uB9C1 fallback\uC774 \uCF1C\uC838 \uC788\uC73C\uBA74 \uD655\uC778 \uC8FC\uAE30\uB294 \uCD5C\uC18C 10\uBD84\uC73C\uB85C \uC790\uB3D9 \uBCF4\uC815\uB429\uB2C8\uB2E4."
  CrawlBusyWarning = U "\uD06C\uB864\uB9C1 \uC870\uD68C \uC911\uC5D0\uB294 Chrome/Edge\uB85C \uD0A4\uC6CC\uB4DC\uBCC4 \uAC80\uC0C9\uC744 \uC218\uD589\uD558\uBBC0\uB85C \uD504\uB85C\uADF8\uB7A8\uC774 \uC7A0\uC2DC \uBA48\uCD98 \uAC83\uCC98\uB7FC \uBCF4\uC77C \uC218 \uC788\uC2B5\uB2C8\uB2E4."
  BudgetLabel = U "\uBC30\uC815\uC608\uC0B0"
  EstimatedLabel = U "\uCD94\uC815\uAC00\uACA9"
  CountSuffix = U "\uAC74"
  TestMessage = U "Windows \uC54C\uB9BC\uC774 \uC815\uC0C1 \uC791\uB3D9\uD569\uB2C8\uB2E4.`n\uBC30\uC815\uC608\uC0B0: 123,456,789\uC6D0"
  HelpText = U "1. \uACF5\uACF5\uB370\uC774\uD130\uD3EC\uD138(data.go.kr)\uC5D0\uC11C \uB098\uB77C\uC7A5\uD130 \uC785\uCC30\uACF5\uACE0\uC815\uBCF4\uC11C\uBE44\uC2A4 \uC778\uC99D\uD0A4\uB97C \uBC1C\uAE09\uBC1B\uC2B5\uB2C8\uB2E4.`r`n2. \uC124\uC815\uC5D0 \uC778\uC99D\uD0A4, \uC6A9\uC5ED \uAD6C\uBD84, \uD655\uC778 \uC8FC\uAE30\uB97C \uC785\uB825\uD569\uB2C8\uB2E4.`r`n3. API \uC694\uCCAD \uC81C\uD55C(429)\uC774 \uBC1C\uC0DD\uD558\uBA74 Chrome/Edge \uAE30\uBC18 \uD06C\uB864\uB9C1 \uBAA8\uB4DC\uB85C \uC790\uB3D9 \uC870\uD68C\uD569\uB2C8\uB2E4.`r`n4. \uD06C\uB864\uB9C1 \uBAA8\uB4DC\uB294 \uD0A4\uC6CC\uB4DC\uBCC4\uB85C \uB098\uB77C\uC7A5\uD130 \uD654\uBA74\uC744 \uAC80\uC0C9\uD558\uBBC0\uB85C \uD0A4\uC6CC\uB4DC\uAC00 \uB9CE\uC73C\uBA74 \uC624\uB798 \uAC78\uB9AC\uBA70, \uC870\uD68C \uC911 \uD504\uB85C\uADF8\uB7A8\uC774 \uC7A0\uC2DC \uBA48\uCD98 \uAC83\uCC98\uB7FC \uBCF4\uC77C \uC218 \uC788\uC2B5\uB2C8\uB2E4.`r`n5. \uD06C\uB864\uB9C1 fallback\uC774 \uCF1C\uC838 \uC788\uC73C\uBA74 \uD655\uC778 \uC8FC\uAE30\uB294 \uCD5C\uC18C 10\uBD84\uC73C\uB85C \uC790\uB3D9 \uBCF4\uC815\uB429\uB2C8\uB2E4.`r`n6. \uD06C\uB864\uB9C1\uC774 \uC624\uB798 \uAC78\uB9AC\uBA74 \uC815\uC9C0\uB97C \uB20C\uB7EC \uD604\uC7AC \uC870\uD68C\uB97C \uC911\uC9C0\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4.`r`n7. \uD06C\uB864\uB9C1 \uACB0\uACFC\uB294 \uC6F9 \uD654\uBA74 \uAE30\uC900\uC774\uB77C \uB9C8\uAC10\uC77C\uC2DC, \uC608\uC0B0, \uC0C1\uC138 \uB9C1\uD06C\uAC00 API\uBCF4\uB2E4 \uC81C\uD55C\uC801\uC73C\uB85C \uD45C\uC2DC\uB420 \uC218 \uC788\uC2B5\uB2C8\uB2E4."
  AlreadyRunning = U "\uB098\uB77C\uC7A5\uD130 \uACF5\uACE0 \uBAA8\uB2C8\uD130\uAC00 \uC774\uBBF8 \uC2E4\uD589 \uC911\uC785\uB2C8\uB2E4."
}

$script:SingleInstanceMutex = $null
$createdNew = $false
try {
  $script:SingleInstanceMutex = New-Object System.Threading.Mutex($true, "Local\G2BBidAlertMonitor.SingleInstance", [ref]$createdNew)
} catch {
  $createdNew = $true
}
if (-not $createdNew) {
  [System.Windows.Forms.MessageBox]::Show($T.AlreadyRunning, $T.AppTitle, "OK", "Information") | Out-Null
  if ($script:SingleInstanceMutex) { $script:SingleInstanceMutex.Dispose() }
  exit 0
}

function Get-DefaultConfig {
  [ordered]@{
    service_key = "PUT_YOUR_SERVICE_KEY_HERE"
    keywords = @()
    service_types = @($T.GeneralService, $T.TechService)
    interval_minutes = 30
    initial_lookback_minutes = 4320
    overlap_minutes = 3
    alert_existing_on_first_run = $true
    windows_notification_enabled = $true
    include_pre_specs = $true
    theme = "blue"
    search_mode = "bulk"
    crawl_fallback_enabled = $true
    num_of_rows = 999
    max_pages_per_check = 3
    timeout_seconds = 45
    request_delay_ms = 1500
    rate_limit_cooldown_minutes = 10
  }
}

function Load-JsonFile($Path, $Default) {
  if (-not (Test-Path -LiteralPath $Path)) { return $Default }
  try { return Get-Content -LiteralPath $Path -Encoding UTF8 -Raw | ConvertFrom-Json } catch { return $Default }
}

function Save-JsonFile($Path, $Value) {
  $Value | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $Path -Encoding UTF8
}

function Compare-AppVersions([string]$Left, [string]$Right) {
  try {
    return ([version]$Left).CompareTo([version]$Right)
  } catch {
    return [string]::Compare($Left, $Right, [StringComparison]::OrdinalIgnoreCase)
  }
}

function Read-UpdateManifest {
  $channelPath = Join-Path $script:AppDir "update_channel.json"
  if (-not (Test-Path -LiteralPath $channelPath)) { throw $T.UpdateNotConfigured }
  $channel = Get-Content -LiteralPath $channelPath -Encoding UTF8 -Raw | ConvertFrom-Json
  $manifestUrl = ([string]$channel.manifest_url).Trim()
  if (-not $manifestUrl) { throw $T.UpdateNotConfigured }
  $manifest = if (Test-Path -LiteralPath $manifestUrl) {
    Get-Content -LiteralPath $manifestUrl -Encoding UTF8 -Raw | ConvertFrom-Json
  } else {
    $separator = if ($manifestUrl.Contains("?")) { "&" } else { "?" }
    $nonce = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
    $response = Invoke-RestMethod -Uri "$manifestUrl$separator`nonce=$nonce" -TimeoutSec 15 -Headers @{
      "User-Agent" = "g2b-bid-alert-update-check/1.0"
      "Cache-Control" = "no-cache"
    }
    if ($response -is [string]) {
      $response.TrimStart([char]0xFEFF) | ConvertFrom-Json
    } else {
      $response
    }
  }
  if (-not $manifest.version -or -not $manifest.package_url -or -not $manifest.sha256) {
    throw $T.UpdateCheckFailed
  }
  return [pscustomobject]@{ Channel = $channel; Manifest = $manifest; ManifestUrl = $manifestUrl }
}

function Set-UpdateBadge([string]$Version = "") {
  if (-not $script:UpdateBadge -or -not $script:UpdateCheckButton) { return }
  if (-not $Version) {
    $script:UpdateBadge.Visible = $false
    $script:UpdateBadge.Text = ""
    $script:UpdateCheckButton.AccessibleDescription = ""
    return
  }
  $script:UpdateBadge.Text = "NEW v$Version"
  $script:UpdateBadge.BackColor = [System.Drawing.Color]::FromArgb(220, 38, 38)
  $script:UpdateBadge.ForeColor = [System.Drawing.Color]::White
  $script:UpdateBadge.Visible = $true
  $script:UpdateBadge.BringToFront()
  $script:UpdateCheckButton.AccessibleDescription = "$($T.UpdateAvailable) v$Version"
}

function Start-AppUpdate($UpdateInfo) {
  $updater = Join-Path $script:AppDir "updater.ps1"
  if (-not (Test-Path -LiteralPath $updater)) { throw "updater.ps1 not found" }
  $tempUpdater = Join-Path $env:TEMP ("g2b-updater-" + [guid]::NewGuid().ToString("N") + ".ps1")
  Copy-Item -LiteralPath $updater -Destination $tempUpdater -Force
  Start-Process -FilePath "powershell.exe" -WindowStyle Hidden -ArgumentList @(
    "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$tempUpdater`"",
    "-ManifestUrl", "`"$($UpdateInfo.ManifestUrl)`"",
    "-AppDir", "`"$script:AppDir`"",
    "-CurrentPid", [string]$PID
  ) | Out-Null
  $script:UpdateInProgress = $true
  $script:Form.Close()
}

function CheckForAppUpdate([bool]$Interactive) {
  try {
    $info = Read-UpdateManifest
    $latest = [string]$info.Manifest.version
    if ((Compare-AppVersions $latest $script:AppVersion) -le 0) {
      $script:AvailableUpdateInfo = $null
      $script:AvailableUpdateVersion = ""
      Set-UpdateBadge
      if ($Interactive) {
        [System.Windows.Forms.MessageBox]::Show("$($T.UpdateCurrent)`r`n`r`nv$script:AppVersion", $T.UpdateCheck, "OK", "Information") | Out-Null
      }
      return
    }

    $script:AvailableUpdateInfo = $info
    $script:AvailableUpdateVersion = $latest
    Set-UpdateBadge $latest
    if (-not $Interactive) { return }

    $notes = ([string]$info.Manifest.release_notes).Trim()
    $message = "$($T.UpdateAvailable)`r`n`r`n$script:AppVersion  →  $latest"
    if ($notes) { $message += "`r`n`r`n$notes" }
    $message += "`r`n`r`n$($T.UpdateNow)"
    $answer = [System.Windows.Forms.MessageBox]::Show($message, $T.UpdateCheck, "YesNo", "Information")
    if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) { Start-AppUpdate $info }
  } catch {
    if ($Interactive) {
      [System.Windows.Forms.MessageBox]::Show("$($T.UpdateCheckFailed)`r`n`r`n$($_.Exception.Message)", $T.UpdateCheck, "OK", "Warning") | Out-Null
    }
  }
}

function To-Hashtable($Object) {
  $hash = @{}
  foreach ($prop in $Object.PSObject.Properties) { $hash[$prop.Name] = $prop.Value }
  return $hash
}

function CompactDate([datetime]$Date) { $Date.ToString("yyyyMMddHHmm") }

function ParseCompactDate([string]$Value) {
  if ([string]::IsNullOrWhiteSpace($Value)) { return $null }
  try { return [datetime]::ParseExact($Value, "yyyyMMddHHmm", $null) } catch { return $null }
}

function ParseNoticeDate([string]$Value) {
  if ([string]::IsNullOrWhiteSpace($Value)) { return $null }
  $formats = @("yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd HH:mm", "yyyy-MM-dd", "yyyy/MM/dd", "yyyyMMddHHmm")
  foreach ($fmt in $formats) {
    try { return [datetime]::ParseExact($Value, $fmt, $null) } catch {}
  }
  try { return [datetime]::Parse($Value) } catch { return $null }
}

function FormatMoney($Value) {
  if ([string]::IsNullOrWhiteSpace([string]$Value)) { return "-" }
  $number = 0L
  if ([long]::TryParse([string]$Value, [ref]$number)) { return $number.ToString("N0") + (U "\uC6D0") }
  return [string]$Value
}

function BudgetText($Notice) {
  $parts = @()
  if ($Notice.budget) { $parts += "$($T.BudgetLabel): $(FormatMoney $Notice.budget)" }
  if ([string]$Notice.sourceType -ne "pre-spec" -and $Notice.estimatedPrice) { $parts += "$($T.EstimatedLabel): $(FormatMoney $Notice.estimatedPrice)" }
  if ($parts.Count -gt 0) { return ($parts -join " / ") }
  return "$($T.Budget): -"
}

function FormatDateOnly($Value) {
  if ([string]::IsNullOrWhiteSpace([string]$Value) -or [string]$Value -eq "-") { return "-" }
  $date = ParseNoticeDate ([string]$Value)
  if ($date) { return $date.ToString("yyyy-MM-dd") }
  if ([string]$Value -match "^(\d{4})[-/](\d{2})[-/](\d{2})") { return "$($matches[1])-$($matches[2])-$($matches[3])" }
  return [string]$Value
}

function FormatCloseText($Value) {
  if ([string]::IsNullOrWhiteSpace([string]$Value) -or [string]$Value -eq "-") { return "-" }
  $closeDt = ParseNoticeDate ([string]$Value)
  if (-not $closeDt) { return [string]$Value }
  $days = [int]($closeDt.Date - (Get-Date).Date).TotalDays
  $dayText = if ($days -gt 0) { "D-$days" } elseif ($days -eq 0) { "D-Day" } else { "D+$([Math]::Abs($days))" }
  return "$(FormatDateOnly $Value) ($dayText)"
}

function NoticeStatusText($Notice, [bool]$IsNew) {
  $labels = @()
  if ($IsNew) { $labels += $T.New }
  if ([string]$Notice.sourceType -eq "pre-spec") { $labels += $T.PreSpec }
  $closeDt = ParseNoticeDate ([string]$Notice.closeDate)
  if ($closeDt -and $closeDt -gt (Get-Date) -and $closeDt -le (Get-Date).AddHours(24)) {
    $labels += $T.ClosingSoon
  }
  if ($labels.Count -eq 0) { return "" }
  return ($labels -join " / ")
}

function IsCancelledNotice($Notice) {
  if (-not $Notice -or [string]$Notice.sourceType -eq "pre-spec") { return $false }
  return ([string]$Notice.noticeKind).Trim() -match (U "\uCDE8\uC18C")
}

function NoticeDedupKey($Notice) {
  $title = ([string]$Notice.title).ToLowerInvariant() -replace "[^\p{L}\p{Nd}]", ""
  $agency = ([string]$Notice.noticeAgency).ToLowerInvariant() -replace "[^\p{L}\p{Nd}]", ""
  $budget = ([string]$Notice.budget) -replace "\D", ""
  if (-not $title -or -not $agency -or -not $budget) { return "" }
  return "$title|$agency|$budget"
}

function CollapseDuplicateNotices($NoticesById) {
  $result = @{}
  $crossSourceKeys = @{}
  foreach ($notice in @($NoticesById.Values | Sort-Object @{ Expression = { [string]$_.sourceType -eq "bid" }; Descending = $true })) {
    if (IsCancelledNotice $notice) { continue }
    $key = NoticeDedupKey $notice
    if (-not $key -or -not $crossSourceKeys.ContainsKey($key)) {
      $result[[string]$notice.id] = $notice
      if ($key) { $crossSourceKeys[$key] = [string]$notice.id }
      continue
    }

    $existingId = [string]$crossSourceKeys[$key]
    $existing = $result[$existingId]
    if ([string]$existing.sourceType -eq [string]$notice.sourceType) {
      $result[[string]$notice.id] = $notice
      continue
    }

    $keywords = @(
      @(([string]$existing.keyword -split ",\s*") + ([string]$notice.keyword -split ",\s*")) |
        Where-Object { $_ } |
        Select-Object -Unique
    )
    $existing.keyword = ($keywords -join ", ")
  }
  return $result
}

function InitializeStarredState {
  $script:StarredIds.Clear()
  $script:StarredNotices = @{}
  $state = if (Test-Path -LiteralPath $script:StarredStatePath) {
    Load-JsonFile $script:StarredStatePath ([pscustomobject]@{})
  } else {
    Load-JsonFile $script:StatePath ([pscustomobject]@{})
  }
  if ($state.PSObject.Properties["starred_ids"]) {
    foreach ($id in @($state.starred_ids)) {
      if ($id) { [void]$script:StarredIds.Add([string]$id) }
    }
  }
  if ($state.PSObject.Properties["starred_notices"]) {
    foreach ($notice in @($state.starred_notices)) {
      if (-not $notice -or -not $notice.id -or (IsCancelledNotice $notice)) { continue }
      $id = [string]$notice.id
      [void]$script:StarredIds.Add($id)
      $script:StarredNotices[$id] = $notice
    }
  }
}

function SaveStarredArchive {
  $archive = [pscustomobject]@{
    starred_ids = @($script:StarredIds)
    starred_notices = @(
      foreach ($id in @($script:StarredIds)) {
        if ($script:StarredNotices.ContainsKey([string]$id)) {
          $script:StarredNotices[[string]$id]
        }
      }
    )
    saved_at = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
  }
  Save-JsonFile $script:StarredStatePath $archive
}

function SaveStarredState {
  $state = Load-JsonFile $script:StatePath ([pscustomobject]@{})
  $saved = [ordered]@{}
  foreach ($property in $state.PSObject.Properties) {
    $saved[$property.Name] = $property.Value
  }
  $saved["starred_ids"] = @($script:StarredIds)
  $saved["starred_notices"] = @(
    foreach ($id in @($script:StarredIds)) {
      if ($script:StarredNotices.ContainsKey([string]$id)) {
        $script:StarredNotices[[string]$id]
      }
    }
  )
  Save-JsonFile $script:StatePath ([pscustomobject]$saved)
  SaveStarredArchive
}

function ApplyResultFilter {
  if (-not $script:Grid -or -not $script:ResultSearchBox) { return }
  $query = $script:ResultSearchBox.Text.Trim()
  $script:Grid.CurrentCell = $null
  foreach ($row in $script:Grid.Rows) {
    if (-not $query) {
      $row.Visible = $true
      continue
    }
    $haystack = @(
      [string]$row.Cells["title"].Value,
      [string]$row.Cells["agency"].Value,
      [string]$row.Cells["keyword"].Value,
      [string]$row.Cells["posted"].Value
    ) -join " "
    $row.Visible = $haystack.IndexOf($query, [StringComparison]::CurrentCultureIgnoreCase) -ge 0
  }
}

function ExportVisibleNoticesToExcel {
  $visibleRows = @($script:Grid.Rows | Where-Object { $_.Visible -and $_.Tag })
  if ($visibleRows.Count -eq 0) {
    [System.Windows.Forms.MessageBox]::Show($T.ExcelNoRows, $T.ExcelExport, "OK", "Information") | Out-Null
    return
  }

  $dialog = New-Object System.Windows.Forms.SaveFileDialog
  $dialog.Title = $T.ExcelExport
  $dialog.Filter = "Excel Workbook (*.xlsx)|*.xlsx"
  $dialog.DefaultExt = "xlsx"
  $dialog.AddExtension = $true
  $dialog.FileName = "$(U '\uB098\uB77C\uC7A5\uD130_\uACF5\uACE0')_$(Get-Date -Format 'yyyyMMdd_HHmm').xlsx"
  if ($dialog.ShowDialog($script:Form) -ne [System.Windows.Forms.DialogResult]::OK) { return }

  $items = @(
    foreach ($row in $visibleRows) {
      $notice = $row.Tag
      [pscustomobject]@{
        starred = $script:StarredIds.Contains([string]$notice.id)
        status = [string]$row.Cells["new"].Value
        title = [string]$notice.title
        type = $(if ([string]$notice.sourceType -eq "pre-spec") { $T.PreSpec } elseif ($notice.serviceType) { [string]$notice.serviceType } else { [string]$notice.noticeKind })
        noticeAgency = [string]$notice.noticeAgency
        demandAgency = [string]$notice.demandAgency
        budget = [string]$notice.budget
        estimatedPrice = [string]$notice.estimatedPrice
        posted = FormatDateOnly $notice.noticeDate
        close = FormatDateOnly $notice.closeDate
        keyword = [string]$notice.keyword
        url = $(if ([string]$notice.detailUrl -match "^https?://") { [string]$notice.detailUrl } else { "" })
        id = [string]$notice.id
      }
    }
  )

  $tempJson = Join-Path $env:TEMP ("g2b-excel-" + [guid]::NewGuid().ToString("N") + ".json")
  try {
    $items | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $tempJson -Encoding UTF8
    $exporter = Join-Path $script:AppDir "export_notice_excel.ps1"
    if (-not (Test-Path -LiteralPath $exporter)) { throw "export_notice_excel.ps1 not found" }
    & $exporter -InputJson $tempJson -OutputPath $dialog.FileName | Out-Null
    [System.Windows.Forms.MessageBox]::Show("$($T.ExcelSaved)`r`n`r`n$($dialog.FileName)", $T.ExcelExport, "OK", "Information") | Out-Null
  } catch {
    [System.Windows.Forms.MessageBox]::Show("$($T.ExcelFailed)`r`n`r`n$($_.Exception.Message)", $T.ExcelExport, "OK", "Error") | Out-Null
  } finally {
    Remove-Item -LiteralPath $tempJson -Force -ErrorAction SilentlyContinue
  }
}

function InvokeBidNoticeRequest($Config, [hashtable]$Params) {
  $query = ($Params.GetEnumerator() | ForEach-Object {
    [Uri]::EscapeDataString($_.Key) + "=" + [Uri]::EscapeDataString([string]$_.Value)
  }) -join "&"
  try {
    return Invoke-RestMethod -Uri "$script:ApiUrl`?$query" -Method Get -TimeoutSec ([int]$Config.timeout_seconds) -Headers @{
      "User-Agent" = "g2b-bid-alert-native/1.0"
    }
  } catch {
    if ($_.Exception.Status -eq [System.Net.WebExceptionStatus]::Timeout -or
        $_.Exception.Message -match "timed out|time.?out|operation has timed out|\uC2DC\uAC04\uC744 \uCD08\uACFC|\uC791\uC5C5 \uC2DC\uAC04") {
      throw $T.ApiTimedOut
    }
    $statusCode = $null
    if ($_.Exception.Response -and $_.Exception.Response.StatusCode) {
      $statusCode = [int]$_.Exception.Response.StatusCode
    }
    if ($statusCode -eq 429 -or $_.Exception.Message -match "429|Too Many Requests") {
      $cooldown = 10
      if ($Config.rate_limit_cooldown_minutes) {
        $cooldown = [Math]::Max(5, [int]$Config.rate_limit_cooldown_minutes)
      }
      $script:RateLimitedUntil = (Get-Date).AddMinutes($cooldown)
      throw $T.RateLimited
    }
    throw
  }
}

function ReadResponseItems($Response) {
  if ($Response.'nkoneps.com.response.ResponseError') {
    $header = $Response.'nkoneps.com.response.ResponseError'.header
    throw "API error $($header.resultCode): $($header.resultMsg)"
  }
  $resultHeader = $Response.response.header
  if ($resultHeader.resultCode -ne "00") { throw "API error $($resultHeader.resultCode): $($resultHeader.resultMsg)" }
  $items = $Response.response.body.items
  if (-not $items) { return @() }
  if ($items -is [array]) { return $items }
  return @($items)
}

function ResponseTotalCount($Response) {
  $body = $Response.response.body
  if ($body -and $body.totalCount) {
    $count = 0
    if ([int]::TryParse([string]$body.totalCount, [ref]$count)) { return $count }
  }
  return 0
}

function QueryKeyword($Config, [string]$Keyword, [datetime]$Start, [datetime]$End) {
  $params = @{
    serviceKey = $Config.service_key
    pageNo = "1"
    numOfRows = [string]$Config.num_of_rows
    type = "json"
    inqryDiv = "1"
    inqryBgnDt = CompactDate $Start
    inqryEndDt = CompactDate $End
    bidNtceNm = $Keyword
  }
  return ReadResponseItems (InvokeBidNoticeRequest $Config $params)
}

function QueryBulkNotices($Config, [datetime]$Start, [datetime]$End) {
  $rows = [Math]::Max(10, [int]$Config.num_of_rows)
  $maxPages = 3
  if ($Config.max_pages_per_check) { $maxPages = [Math]::Max(1, [int]$Config.max_pages_per_check) }
  $all = @()

  for ($page = 1; $page -le $maxPages; $page += 1) {
    if ($page -gt 1) {
      $delay = 1500
      if ($Config.request_delay_ms) { $delay = [Math]::Max(500, [int]$Config.request_delay_ms) }
      Start-Sleep -Milliseconds $delay
      [System.Windows.Forms.Application]::DoEvents()
    }
    $params = @{
      serviceKey = $Config.service_key
      pageNo = [string]$page
      numOfRows = [string]$rows
      type = "json"
      inqryDiv = "1"
      inqryBgnDt = CompactDate $Start
      inqryEndDt = CompactDate $End
    }
    $response = InvokeBidNoticeRequest $Config $params
    $items = @(ReadResponseItems $response)
    $all += $items
    $total = ResponseTotalCount $response
    if ($items.Count -lt $rows -or ($total -gt 0 -and ($page * $rows) -ge $total)) { break }
  }

  return $all
}

function InvokePreSpecRequest($Config, [hashtable]$Params) {
  $query = ($Params.GetEnumerator() | ForEach-Object {
    [Uri]::EscapeDataString($_.Key) + "=" + [Uri]::EscapeDataString([string]$_.Value)
  }) -join "&"
  try {
    return Invoke-RestMethod -Uri "$script:PreSpecApiUrl`?$query" -Method Get -TimeoutSec ([int]$Config.timeout_seconds) -Headers @{
      "User-Agent" = "g2b-bid-alert-native/1.0"
    }
  } catch {
    if ($_.Exception.Status -eq [System.Net.WebExceptionStatus]::Timeout -or
        $_.Exception.Message -match "timed out|time.?out|operation has timed out|\uC2DC\uAC04\uC744 \uCD08\uACFC|\uC791\uC5C5 \uC2DC\uAC04") {
      throw $T.ApiTimedOut
    }
    $statusCode = $null
    if ($_.Exception.Response -and $_.Exception.Response.StatusCode) {
      $statusCode = [int]$_.Exception.Response.StatusCode
    }
    if ($statusCode -eq 401 -or $statusCode -eq 403) { throw "PRE_SPEC_API_DENIED" }
    if ($statusCode -eq 429 -or $_.Exception.Message -match "429|Too Many Requests") { throw $T.RateLimited }
    throw
  }
}

function QueryPreSpecs($Config, [string]$Keyword, [datetime]$Start, [datetime]$End) {
  $rows = [Math]::Max(10, [int]$Config.num_of_rows)
  $maxPages = [Math]::Max(1, [int]$Config.max_pages_per_check)
  $all = @()
  for ($page = 1; $page -le $maxPages; $page += 1) {
    $params = @{
      serviceKey = $Config.service_key
      pageNo = [string]$page
      numOfRows = [string]$rows
      type = "json"
      inqryDiv = "1"
      inqryBgnDt = CompactDate $Start
      inqryEndDt = CompactDate $End
      prdctClsfcNoNm = $Keyword
    }
    $response = InvokePreSpecRequest $Config $params
    $items = @(ReadResponseItems $response)
    $all += $items
    $total = ResponseTotalCount $response
    if ($items.Count -lt $rows -or ($total -gt 0 -and ($page * $rows) -ge $total)) { break }
  }
  return $all
}

function FirstItemValue($Item, [string[]]$Names) {
  foreach ($name in $Names) {
    $prop = $Item.PSObject.Properties[$name]
    if ($prop -and -not [string]::IsNullOrWhiteSpace([string]$prop.Value)) { return [string]$prop.Value }
  }
  return ""
}

function NewPreSpec($Keyword, $Item) {
  $number = FirstItemValue $Item @("bfSpecRgstNo", "prearngPrceNo", "rgstNo")
  if (-not $number) { return $null }
  $title = FirstItemValue $Item @("bfSpecNm", "prdctClsfcNoNm", "prdctNm", "specNm", "bsnsNm")
  if (-not $title) { return $null }
  [pscustomobject]@{
    keyword = $Keyword
    id = "PRESPEC-$number"
    title = $title.Trim()
    sourceType = "pre-spec"
    noticeKind = $T.PreSpec
    noticeAgency = FirstItemValue $Item @("orderInsttNm", "ntceInsttNm", "pubInsttNm")
    demandAgency = FirstItemValue $Item @("rlDminsttNm", "dminsttNm")
    noticeDate = FirstItemValue $Item @("rgstDt", "bfSpecRgstDt", "rcptDt", "publicDt")
    closeDate = FirstItemValue $Item @("opninRgstClseDt", "clseDt")
    budget = FirstItemValue $Item @("asignBdgtAmt", "budgetAmt")
    estimatedPrice = ""
    detailUrl = "prespec:$number"
  }
}

function MatchingKeywords([string]$Title, $Keywords) {
  $matches = @()
  foreach ($keyword in @($Keywords)) {
    $kw = ([string]$keyword).Trim()
    if (-not $kw) { continue }
    if ($Title.IndexOf($kw, [StringComparison]::CurrentCultureIgnoreCase) -ge 0) { $matches += $kw }
  }
  return $matches
}

function StopProcessTree($Process) {
  if (-not $Process) { return }
  try {
    Start-Process -FilePath "taskkill.exe" -WindowStyle Hidden -Wait -ArgumentList @("/PID", [string]$Process.Id, "/T", "/F") | Out-Null
  } catch {
    try { if (-not $Process.HasExited) { $Process.Kill() } } catch {}
  }
}

function QueryCrawlerNotices {
  $crawler = Join-Path $script:AppDir "g2b_web_crawler.ps1"
  if (-not (Test-Path -LiteralPath $crawler)) { throw $T.CrawlFailed }
  SaveConfig
  $outPath = Join-Path $env:TEMP ("g2b-crawler-out-" + [guid]::NewGuid().ToString("N") + ".json")
  $errPath = Join-Path $env:TEMP ("g2b-crawler-err-" + [guid]::NewGuid().ToString("N") + ".txt")
  try {
    $script:CurrentCrawlerProcess = Start-Process -FilePath "powershell.exe" -WindowStyle Hidden -PassThru `
      -RedirectStandardOutput $outPath -RedirectStandardError $errPath `
      -ArgumentList @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$crawler`"", "-ConfigPath", "`"$script:ConfigPath`"")
    $crawlerTimeoutSeconds = [Math]::Max(180, @($script:Config.keywords).Count * 45)
    $crawlerDeadline = (Get-Date).AddSeconds($crawlerTimeoutSeconds)
    while (-not $script:CurrentCrawlerProcess.HasExited) {
      if ($script:CancelRequested) {
        StopProcessTree $script:CurrentCrawlerProcess
        throw $T.Cancelled
      }
      if ((Get-Date) -ge $crawlerDeadline) {
        StopProcessTree $script:CurrentCrawlerProcess
        throw $T.TemporaryFailure
      }
      Start-Sleep -Milliseconds 200
      [System.Windows.Forms.Application]::DoEvents()
    }
    if ($script:CancelRequested) { throw $T.Cancelled }
    if ($script:CurrentCrawlerProcess.ExitCode -ne 0) { throw $T.CrawlFailed }
    $text = ""
    if (Test-Path -LiteralPath $outPath) { $text = (Get-Content -LiteralPath $outPath -Encoding UTF8 -Raw).Trim() }
    if (-not $text) { return @() }
    $items = $text | ConvertFrom-Json
    if (-not $items) { return @() }
    if ($items -is [array]) { return $items }
    return @($items)
  } finally {
    if ($script:CurrentCrawlerProcess -and -not $script:CurrentCrawlerProcess.HasExited) {
      StopProcessTree $script:CurrentCrawlerProcess
    }
    $script:CurrentCrawlerProcess = $null
    Remove-Item -LiteralPath $outPath -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $errPath -Force -ErrorAction SilentlyContinue
  }
}

function IsWebServiceType($ServiceType) {
  return [string]$ServiceType -eq (U "\uC6A9\uC5ED(\uC6F9)") -or [string]$ServiceType -eq $T.WebServiceBoth
}

function WebServiceTypeLabel {
  $types = @($script:Config.service_types)
  if ($types.Count -eq 1) { return "$($types[0])$($T.WebSuffix)" }
  return $T.WebServiceBoth
}

function NormalizeCrawlerNotice($Notice) {
  if ($Notice -and (IsWebServiceType $Notice.serviceType)) {
    $Notice.serviceType = WebServiceTypeLabel
  }
  if ($Notice -and -not $Notice.PSObject.Properties["sourceType"]) {
    $Notice | Add-Member -NotePropertyName sourceType -NotePropertyValue "bid"
  }
  return $Notice
}

function CrawlerStatusText {
  if (-not (Test-Path -LiteralPath $script:CrawlerStatusPath)) { return $T.CrawlingNoMatch }
  try {
    $stats = Get-Content -LiteralPath $script:CrawlerStatusPath -Encoding UTF8 -Raw | ConvertFrom-Json
    $checked = U "\uD655\uC778"
    $service = U "\uC6A9\uC5ED"
    $matched = U "\uC77C\uCE58"
    return "$($T.CrawlingNoMatch) ($($stats.scanned_rows)$($T.CountSuffix) $checked, $service $($stats.service_rows)$($T.CountSuffix), $matched $($stats.matched_rows)$($T.CountSuffix))"
  } catch {
    return $T.CrawlingNoMatch
  }
}

function ShowWindowsNotification($Title, $Message, $Url) {
  $scriptPath = Join-Path $script:AppDir "show_windows_notification.ps1"
  if (-not (Test-Path -LiteralPath $scriptPath)) { return }
  Start-Process -FilePath "powershell.exe" -WindowStyle Hidden -ArgumentList @(
    "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$scriptPath`"",
    "-Title", "`"$Title`"", "-Message", "`"$Message`"", "-Url", "`"$Url`""
  ) | Out-Null
}

function NewNotice($Keyword, $Item) {
  $bidNo = [string]$Item.bidNtceNo
  $bidOrd = [string]$Item.bidNtceOrd
  if (-not $bidNo -or -not $bidOrd) { return $null }
  $notice = [pscustomobject]@{
    keyword = $Keyword
    id = "$bidNo-$bidOrd"
    title = ([string]$Item.bidNtceNm).Trim()
    sourceType = "bid"
    serviceType = [string]$Item.srvceDivNm
    noticeKind = [string]$Item.ntceKindNm
    noticeAgency = [string]$Item.ntceInsttNm
    demandAgency = [string]$Item.dminsttNm
    noticeDate = [string]$(if ($Item.bidNtceDt) { $Item.bidNtceDt } else { $Item.rgstDt })
    closeDate = [string]$(if ($Item.bidClseDt) { $Item.bidClseDt } else { $Item.opengDt })
    budget = [string]$Item.asignBdgtAmt
    estimatedPrice = [string]$Item.presmptPrce
    detailUrl = [string]$(if ($Item.bidNtceDtlUrl) { $Item.bidNtceDtlUrl } else { $Item.bidNtceUrl })
  }
  if (IsCancelledNotice $notice) { return $null }
  return $notice
}

function CurrentKeywords {
  $items = @()
  foreach ($item in $script:KeywordList.Items) { $items += [string]$item }
  return $items
}

function UpdateStartButtonState {
  if (-not $script:StartButton -or -not $script:KeywordList) { return }
  $script:StartButton.Enabled = ($script:KeywordList.Items.Count -gt 0)
}

function UpdateKeywordListLayout {
  if (-not $script:KeywordList -or $script:KeywordList.ClientSize.Height -le 0) { return }
  $targetHeight = [Math]::Floor($script:KeywordList.ClientSize.Height / 6)
  $minimumHeight = $script:KeywordList.Font.Height + 1
  $itemHeight = [Math]::Max($minimumHeight, $targetHeight)
  if ($script:KeywordList.ItemHeight -ne $itemHeight) {
    $script:KeywordList.ItemHeight = $itemHeight
  }
}

function SaveConfig {
  $script:Config.keywords = @(CurrentKeywords)
  Save-JsonFile $script:ConfigPath $script:Config
}

function EffectiveIntervalMinutes {
  $minutes = [Math]::Max(1, [int]$script:Config.interval_minutes)
  if ([bool]$script:Config.crawl_fallback_enabled -and $minutes -lt 10) { return 10 }
  return $minutes
}

function EnforceIntervalPolicy {
  if ([bool]$script:Config.crawl_fallback_enabled -and [int]$script:Config.interval_minutes -lt 10) {
    $script:Config.interval_minutes = 10
    return $true
  }
  return $false
}

function SetStatus($Text) {
  $script:StatusValue.Text = $Text
  [System.Windows.Forms.Application]::DoEvents()
}

function SetDataMode($Text) {
  if ($script:ModeValue) { $script:ModeValue.Text = $Text }
  [System.Windows.Forms.Application]::DoEvents()
}

function SetNextCheckFromNow {
  $script:NextCheckAt = (Get-Date).AddMinutes((EffectiveIntervalMinutes))
  UpdateCountdownLabel
}

function ClearNextCheck {
  $script:NextCheckAt = $null
  if ($script:NextValue) { $script:NextValue.Text = "-" }
}

function UpdateCountdownLabel {
  if (-not $script:NextValue) { return }
  if (-not $script:NextCheckAt) {
    $script:NextValue.Text = "-"
    return
  }
  $remaining = $script:NextCheckAt - (Get-Date)
  if ($remaining.TotalSeconds -le 0) {
    $script:NextValue.Text = $T.NowChecking
    return
  }
  $script:NextValue.Text = "{0:00}:{1:00}" -f [Math]::Floor($remaining.TotalMinutes), $remaining.Seconds
}

function RateLimitMessage {
  if ($script:RateLimitedUntil) {
    return "$($T.RateLimitedWait): $($script:RateLimitedUntil.ToString("HH:mm"))"
  }
  return $T.RateLimited
}

function HandleCheckFailure($Exception) {
  $message = [string]$Exception.Message
  if ($message -eq $T.Cancelled) {
    SetStatus $T.Cancelled
    ClearNextCheck
  } elseif ($message -eq $T.RateLimited) {
    SetStatus "$(RateLimitMessage) - $($T.RateLimitHint)"
  } elseif ($message -eq $T.ApiTimedOut -or $message -eq $T.TemporaryFailure -or
            $message -match "timed out|time.?out|operation has timed out|\uC2DC\uAC04\uC744 \uCD08\uACFC|\uC791\uC5C5 \uC2DC\uAC04") {
    SetStatus $T.TemporaryFailure
  } else {
    SetStatus $message
    [System.Windows.Forms.MessageBox]::Show($message, "Error", "OK", "Error") | Out-Null
  }
}

function RequestStop {
  $timer.Stop()
  $script:CancelRequested = $true
  ClearNextCheck
  if ($script:CurrentCrawlerProcess -and -not $script:CurrentCrawlerProcess.HasExited) {
    SetStatus $T.Stopping
    StopProcessTree $script:CurrentCrawlerProcess
  } else {
    SetStatus $T.Stopped
  }
}

function ThemeColors {
  param([string]$Theme)
  switch ($Theme) {
    "mint" {
      return @{
        Back = [System.Drawing.Color]::FromArgb(241, 248, 246)
        Panel = [System.Drawing.Color]::White
        Soft = [System.Drawing.Color]::FromArgb(232, 248, 243)
        Ink = [System.Drawing.Color]::FromArgb(16, 32, 29)
        Muted = [System.Drawing.Color]::FromArgb(88, 113, 107)
        Accent = [System.Drawing.Color]::FromArgb(15, 118, 110)
        Accent2 = [System.Drawing.Color]::FromArgb(37, 99, 235)
        ButtonText = [System.Drawing.Color]::White
        NewBack = [System.Drawing.Color]::FromArgb(220, 252, 231)
        NewInk = [System.Drawing.Color]::FromArgb(20, 83, 45)
      }
    }
    "charcoal" {
      return @{
        Back = [System.Drawing.Color]::FromArgb(17, 24, 39)
        Panel = [System.Drawing.Color]::FromArgb(31, 41, 55)
        Soft = [System.Drawing.Color]::FromArgb(24, 34, 48)
        Ink = [System.Drawing.Color]::FromArgb(248, 250, 252)
        Muted = [System.Drawing.Color]::FromArgb(168, 179, 196)
        Accent = [System.Drawing.Color]::FromArgb(56, 189, 248)
        Accent2 = [System.Drawing.Color]::FromArgb(245, 158, 11)
        ButtonText = [System.Drawing.Color]::FromArgb(15, 23, 42)
        NewBack = [System.Drawing.Color]::FromArgb(12, 74, 110)
        NewInk = [System.Drawing.Color]::FromArgb(240, 249, 255)
      }
    }
    default {
      return @{
        Back = [System.Drawing.Color]::FromArgb(245, 247, 251)
        Panel = [System.Drawing.Color]::White
        Soft = [System.Drawing.Color]::FromArgb(238, 244, 255)
        Ink = [System.Drawing.Color]::FromArgb(23, 32, 44)
        Muted = [System.Drawing.Color]::FromArgb(100, 112, 132)
        Accent = [System.Drawing.Color]::FromArgb(19, 95, 219)
        Accent2 = [System.Drawing.Color]::FromArgb(15, 118, 110)
        ButtonText = [System.Drawing.Color]::White
        NewBack = [System.Drawing.Color]::FromArgb(232, 247, 255)
        NewInk = [System.Drawing.Color]::FromArgb(12, 53, 82)
      }
    }
  }
}

function ApplyNoticeRowStyle($Row, [bool]$IsNew) {
  $colors = ThemeColors ([string]$script:Config.theme)
  $Row.DefaultCellStyle.BackColor = $(if ($IsNew) { $colors.NewBack } else { $colors.Panel })
  $Row.DefaultCellStyle.ForeColor = $(if ($IsNew) { $colors.NewInk } else { $colors.Ink })
  $Row.DefaultCellStyle.SelectionBackColor = $colors.Accent
  $Row.DefaultCellStyle.SelectionForeColor = $colors.ButtonText
  ApplyStarCellStyle $Row
}

function ApplyStarCellStyle($Row) {
  if (-not $Row -or -not $script:Grid -or -not $script:Grid.Columns.Contains("star")) { return }
  $colors = ThemeColors ([string]$script:Config.theme)
  $id = [string]$Row.Cells["internalId"].Value
  $isStarred = $id -and $script:StarredIds.Contains($id)
  $cell = $Row.Cells["star"]
  $cell.Value = $(if ($isStarred) { U "\u2605" } else { U "\u2606" })
  $cell.Style.Alignment = [System.Windows.Forms.DataGridViewContentAlignment]::MiddleCenter
  $cell.Style.Font = New-Object System.Drawing.Font("Segoe UI Symbol", 14, [System.Drawing.FontStyle]::Regular)
  $cell.Style.ForeColor = $(if ($isStarred) { [System.Drawing.Color]::FromArgb(245, 158, 11) } else { $colors.Muted })
  $cell.Style.SelectionForeColor = $(if ($isStarred) { [System.Drawing.Color]::FromArgb(255, 211, 77) } else { $colors.ButtonText })
}

function PaintControl($Control, $Colors) {
  if ($Control -is [System.Windows.Forms.Form]) {
    $Control.BackColor = $Colors.Back
    $Control.ForeColor = $Colors.Ink
  } elseif ($Control -is [System.Windows.Forms.TextBox] -or $Control -is [System.Windows.Forms.NumericUpDown] -or $Control -is [System.Windows.Forms.ComboBox]) {
    $Control.BackColor = [System.Drawing.Color]::White
    $Control.ForeColor = [System.Drawing.Color]::FromArgb(23, 32, 44)
  } elseif ($Control -is [System.Windows.Forms.Button]) {
    $Control.BackColor = $Colors.Panel
    $Control.ForeColor = $Colors.Ink
    $Control.FlatStyle = "Flat"
    $Control.FlatAppearance.BorderColor = $Colors.Muted
  } elseif ($Control -is [System.Windows.Forms.GroupBox] -or $Control -is [System.Windows.Forms.Panel] -or $Control -is [System.Windows.Forms.TableLayoutPanel] -or $Control -is [System.Windows.Forms.FlowLayoutPanel]) {
    $Control.BackColor = $Colors.Panel
    $Control.ForeColor = $Colors.Ink
  } elseif ($Control -is [System.Windows.Forms.DataGridView]) {
    $Control.BackgroundColor = $Colors.Panel
    $Control.GridColor = $Colors.Muted
    $Control.DefaultCellStyle.BackColor = $Colors.Panel
    $Control.DefaultCellStyle.ForeColor = $Colors.Ink
    $Control.DefaultCellStyle.SelectionBackColor = $Colors.Accent
    $Control.DefaultCellStyle.SelectionForeColor = $Colors.ButtonText
    $Control.ColumnHeadersDefaultCellStyle.BackColor = $Colors.Soft
    $Control.ColumnHeadersDefaultCellStyle.ForeColor = $Colors.Ink
    $Control.EnableHeadersVisualStyles = $false
  } else {
    $Control.BackColor = $Colors.Panel
    $Control.ForeColor = $Colors.Ink
  }
  foreach ($child in $Control.Controls) { PaintControl $child $Colors }
}

function ApplyTheme {
  $colors = ThemeColors ([string]$script:Config.theme)
  $script:Form.BackColor = $colors.Back
  PaintControl $script:Form $colors
  $script:TitleLabel.Font = New-Object System.Drawing.Font("Malgun Gothic", 19, [System.Drawing.FontStyle]::Bold)
  $script:MetaLabel.Font = New-Object System.Drawing.Font("Malgun Gothic", 8.5, [System.Drawing.FontStyle]::Regular)
  $script:MetaLabel.ForeColor = $colors.Muted
  $script:MetaLabel.LinkColor = $colors.Accent
  $script:MetaLabel.ActiveLinkColor = $colors.Accent2
  $script:MetaLabel.VisitedLinkColor = $colors.Accent
  if ($script:ResetWarningLabel) {
    $script:ResetWarningLabel.ForeColor = [System.Drawing.Color]::FromArgb(220, 38, 38)
  }
  if ($script:KeywordCountWarningLabel) {
    $script:KeywordCountWarningLabel.ForeColor = [System.Drawing.Color]::FromArgb(220, 38, 38)
  }
  $script:StartButton.BackColor = $colors.Accent
  $script:StartButton.ForeColor = $colors.ButtonText
  $script:KeywordPanel.BackColor = $colors.Soft
  $script:StatusValue.ForeColor = $colors.Accent
  foreach ($row in $script:Grid.Rows) {
    ApplyNoticeRowStyle $row ([string]$row.Cells["new"].Value -match [regex]::Escape($T.New))
  }
  if ($script:AvailableUpdateVersion) { Set-UpdateBadge $script:AvailableUpdateVersion }
}

function AddNoticeRow($Notice, [bool]$IsNew) {
  if (IsCancelledNotice $Notice) { return }
  $noticeId = [string]$Notice.id
  $isStarred = $noticeId -and $script:StarredIds.Contains($noticeId)
  if ($isStarred) { $script:StarredNotices[$noticeId] = $Notice }
  $row = $null
  foreach ($candidate in $script:Grid.Rows) {
    if ([string]$candidate.Cells["internalId"].Value -eq [string]$Notice.id) {
      $row = $candidate
      break
    }
  }
  if (-not $row) {
    $starredRowCount = @($script:Grid.Rows | Where-Object {
      $script:StarredIds.Contains([string]$_.Cells["internalId"].Value)
    }).Count
    $rowIndex = if ($isStarred) {
      $script:Grid.Rows.Insert(0, 1)
      0
    } elseif ($IsNew) {
      $script:Grid.Rows.Insert($starredRowCount, 1)
      $starredRowCount
    } else {
      $script:Grid.Rows.Add()
    }
    $row = $script:Grid.Rows[$rowIndex]
  }
  $row.Tag = $Notice
  $row.Cells["internalId"].Value = $Notice.id
  $row.Cells["sourceType"].Value = $Notice.sourceType
  $row.Cells["closeRaw"].Value = $Notice.closeDate
  $row.Cells["new"].Value = NoticeStatusText $Notice $IsNew
  $row.Cells["title"].Value = $Notice.title
  $row.Cells["agency"].Value = $Notice.noticeAgency
  $row.Cells["budget"].Value = $(if ([string]$Notice.sourceType -eq "pre-spec") {
    if ($Notice.budget) { FormatMoney $Notice.budget } else { "-" }
  } else {
    $parts = @()
    if ($Notice.budget) { $parts += "$($T.BudgetLabel): $(FormatMoney $Notice.budget)" }
    if ($Notice.estimatedPrice) { $parts += "$($T.EstimatedLabel): $(FormatMoney $Notice.estimatedPrice)" }
    if ($parts.Count -gt 0) { $parts -join " / " } else { "-" }
  })
  $row.Cells["posted"].Value = FormatDateOnly $Notice.noticeDate
  $row.Cells["close"].Value = FormatCloseText $Notice.closeDate
  $row.Cells["keyword"].Value = $Notice.keyword
  $row.Cells["url"].Value = $Notice.detailUrl
  ApplyNoticeRowStyle $row $IsNew
  ApplyResultFilter
}

function ToggleStarredRow($Row) {
  if (-not $Row) { return }
  $id = [string]$Row.Cells["internalId"].Value
  if (-not $id) { return }
  $notice = $Row.Tag
  if (-not $notice) { return }
  $isNew = [string]$Row.Cells["new"].Value -match [regex]::Escape($T.New)
  if ($script:StarredIds.Contains($id)) {
    [void]$script:StarredIds.Remove($id)
    [void]$script:StarredNotices.Remove($id)
  } else {
    [void]$script:StarredIds.Add($id)
    $script:StarredNotices[$id] = $notice
  }
  $script:Grid.Rows.Remove($Row)
  AddNoticeRow $notice $isNew
  SaveStarredState
}

function RefreshExistingRowStatuses($ActiveNewIds) {
  foreach ($row in $script:Grid.Rows) {
    $id = [string]$row.Cells["internalId"].Value
    if (-not $id) { continue }
    $showNew = $ActiveNewIds.Contains($id)
    $notice = [pscustomobject]@{
      sourceType = [string]$row.Cells["sourceType"].Value
      closeDate = [string]$row.Cells["closeRaw"].Value
    }
    $row.Cells["new"].Value = NoticeStatusText $notice $showNew
    ApplyNoticeRowStyle $row $showNew
  }
}

function CheckNotices([bool]$ForceLookback, [bool]$SilentNotification) {
  SaveConfig
  if (-not $script:Config.service_key -or $script:Config.service_key -eq "PUT_YOUR_SERVICE_KEY_HERE") { throw $T.EnterKey }
  if (-not $script:Config.keywords -or $script:Config.keywords.Count -eq 0) { throw $T.EnterKeyword }
  if (-not $script:Config.service_types -or $script:Config.service_types.Count -eq 0) { throw $T.SelectType }
  $forceCrawler = $false
  if ($script:RateLimitedUntil -and (Get-Date) -lt $script:RateLimitedUntil -and [bool]$script:Config.crawl_fallback_enabled) {
    $forceCrawler = $true
  } elseif ($script:RateLimitedUntil -and (Get-Date) -lt $script:RateLimitedUntil) {
    SetStatus "$(RateLimitMessage) - $($T.RateLimitHint)"
    return
  }
  if (-not $forceCrawler) { $script:RateLimitedUntil = $null }

  $state = Load-JsonFile $script:StatePath ([pscustomobject]@{ seen_ids = @(); first_seen = [pscustomobject]@{}; active_new_ids = @(); active_new_notices = @(); starred_ids = @(); starred_notices = @(); last_checked = "" })
  $seen = New-Object "System.Collections.Generic.HashSet[string]"
  foreach ($id in @($state.seen_ids)) { [void]$seen.Add([string]$id) }
  foreach ($id in @($script:StarredIds)) { [void]$seen.Add([string]$id) }
  $firstSeen = @{}
  if ($state.first_seen) {
    foreach ($prop in $state.first_seen.PSObject.Properties) { $firstSeen[$prop.Name] = [string]$prop.Value }
  }
  $now = Get-Date
  foreach ($id in @($seen)) {
    if (-not $firstSeen.ContainsKey($id)) { $firstSeen[$id] = CompactDate $now.AddDays(-1) }
  }
  $activeNewIds = New-Object "System.Collections.Generic.HashSet[string]"
  if ($state.PSObject.Properties["active_new_ids"]) {
    foreach ($id in @($state.active_new_ids)) { if ($id) { [void]$activeNewIds.Add([string]$id) } }
  } else {
    foreach ($id in @($seen)) {
      $firstSeenDate = ParseCompactDate ([string]$firstSeen[$id])
      if ($firstSeenDate -and $firstSeenDate.Date -eq $now.Date) { [void]$activeNewIds.Add($id) }
    }
  }
  if ($state.PSObject.Properties["active_new_notices"]) {
    foreach ($notice in @($state.active_new_notices)) {
      if ($notice -and (IsCancelledNotice $notice)) {
        [void]$activeNewIds.Remove([string]$notice.id)
      }
    }
  }
  RefreshExistingRowStatuses $activeNewIds
  $previous = ParseCompactDate ([string]$state.last_checked)
  if ($ForceLookback -or -not $previous) { $start = $now.AddMinutes(-[int]$script:Config.initial_lookback_minutes) } else { $start = $previous.AddMinutes(-[int]$script:Config.overlap_minutes) }

  SetStatus $(if ($forceCrawler) { $T.Crawling } else { $T.Checking })
  $byId = @{}
  $usedCrawler = $false
  $preSpecDenied = $false
  SetDataMode $T.ApiThenCrawlMode
  if ($forceCrawler) {
    SetDataMode $T.CrawlMode
    $usedCrawler = $true
    foreach ($notice in (QueryCrawlerNotices)) {
      if (-not $notice) { continue }
      if ((IsWebServiceType $notice.serviceType)) { $notice = NormalizeCrawlerNotice $notice }
      elseif (@($script:Config.service_types) -notcontains $notice.serviceType) { continue }
      if (-not $byId.ContainsKey($notice.id)) { $byId[$notice.id] = $notice }
    }
  } elseif ([string]$script:Config.search_mode -eq "keyword") {
    $keywordIndex = 0
    foreach ($keyword in @($script:Config.keywords)) {
      if ($keywordIndex -gt 0) {
        $delay = 1500
        if ($script:Config.request_delay_ms) { $delay = [Math]::Max(500, [int]$script:Config.request_delay_ms) }
        Start-Sleep -Milliseconds $delay
        [System.Windows.Forms.Application]::DoEvents()
      }
      SetStatus "$($T.Checking): $keyword"
      foreach ($item in (QueryKeyword $script:Config $keyword $start $now)) {
        $notice = NewNotice $keyword $item
        if (-not $notice) { continue }
        if (@($script:Config.service_types) -notcontains $notice.serviceType) { continue }
        if (-not $byId.ContainsKey($notice.id)) { $byId[$notice.id] = $notice }
      }
      $keywordIndex += 1
    }
  } else {
    SetStatus "$($T.Checking): $($T.Keywords)"
    try {
      foreach ($item in (QueryBulkNotices $script:Config $start $now)) {
        $title = [string]$item.bidNtceNm
        $matches = @(MatchingKeywords $title $script:Config.keywords)
        if ($matches.Count -eq 0) { continue }
        $notice = NewNotice ($matches -join ", ") $item
        if (-not $notice) { continue }
        if (@($script:Config.service_types) -notcontains $notice.serviceType) { continue }
        if (-not $byId.ContainsKey($notice.id)) { $byId[$notice.id] = $notice }
      }
      SetDataMode $T.ApiMode
    } catch {
      $apiFailure = [string]$_.Exception.Message
      if (($apiFailure -ne $T.RateLimited -and $apiFailure -ne $T.ApiTimedOut) -or -not [bool]$script:Config.crawl_fallback_enabled) { throw }
      SetStatus $T.Crawling
      SetDataMode $T.CrawlMode
      $usedCrawler = $true
      try {
        foreach ($notice in (QueryCrawlerNotices)) {
          if (-not $notice) { continue }
          if ((IsWebServiceType $notice.serviceType)) { $notice = NormalizeCrawlerNotice $notice }
          elseif (@($script:Config.service_types) -notcontains $notice.serviceType) { continue }
          if (-not $byId.ContainsKey($notice.id)) { $byId[$notice.id] = $notice }
        }
      } catch {
        if ([string]$_.Exception.Message -eq $T.Cancelled) { throw }
        throw $T.TemporaryFailure
      }
      SetStatus $T.CrawlingUsed
    }
  }

  if ([bool]$script:Config.include_pre_specs) {
    try {
      foreach ($keyword in @($script:Config.keywords)) {
        foreach ($item in (QueryPreSpecs $script:Config ([string]$keyword) $start $now)) {
          $candidateTitle = FirstItemValue $item @("bfSpecNm", "prdctClsfcNoNm", "prdctNm", "specNm", "bsnsNm")
          $matches = @(MatchingKeywords $candidateTitle $script:Config.keywords)
          if ($matches.Count -eq 0) { continue }
          $notice = NewPreSpec ($matches -join ", ") $item
          if (-not $notice) { continue }
          if ($byId.ContainsKey($notice.id)) {
            $existing = $byId[$notice.id]
            $merged = @(([string]$existing.keyword -split ",\s*") + $matches | Where-Object { $_ } | Select-Object -Unique)
            $existing.keyword = ($merged -join ", ")
          } else {
            $byId[$notice.id] = $notice
          }
        }
      }
    } catch {
      if ([string]$_.Exception.Message -eq "PRE_SPEC_API_DENIED") {
        $preSpecDenied = $true
      } elseif ([string]$_.Exception.Message -eq $T.ApiTimedOut) {
        # 입찰공고 결과는 유지하고 다음 주기에 사전규격만 다시 시도합니다.
      } else {
        $preSpecDenied = $true
      }
    }
  }

  $byId = CollapseDuplicateNotices $byId
  foreach ($id in @($script:StarredIds)) {
    $starredId = [string]$id
    if ($byId.ContainsKey($starredId)) {
      $script:StarredNotices[$starredId] = $byId[$starredId]
    } elseif ($script:StarredNotices.ContainsKey($starredId)) {
      $savedNotice = $script:StarredNotices[$starredId]
      if (-not (IsCancelledNotice $savedNotice)) { $byId[$starredId] = $savedNotice }
    }
  }

  $firstRun = (-not $state.last_checked) -and ($seen.Count -eq 0)
  $newNotices = @()
  foreach ($notice in @($byId.Values)) {
    if (-not $seen.Contains($notice.id)) { $newNotices += $notice }
  }
  if ($newNotices.Count -gt 0) {
    $activeNewIds.Clear()
    foreach ($notice in $newNotices) { [void]$activeNewIds.Add([string]$notice.id) }
    RefreshExistingRowStatuses $activeNewIds
  } elseif ($state.PSObject.Properties["active_new_notices"]) {
    foreach ($notice in @($state.active_new_notices)) {
      if (-not $notice -or (IsCancelledNotice $notice) -or -not $activeNewIds.Contains([string]$notice.id)) {
        if ($notice -and (IsCancelledNotice $notice)) { [void]$activeNewIds.Remove([string]$notice.id) }
        continue
      }
      if (-not $byId.ContainsKey([string]$notice.id)) { $byId[[string]$notice.id] = $notice }
    }
  }
  foreach ($notice in @($byId.Values | Sort-Object @{ Expression = { $script:StarredIds.Contains([string]$_.id) }; Ascending = $true }, @{ Expression = { $seen.Contains($_.id) }; Ascending = $true }, @{ Expression = { ParseNoticeDate ([string]$_.noticeDate) }; Ascending = $true })) {
    $isNew = -not $seen.Contains($notice.id)
    if ($isNew) {
      $firstSeen[$notice.id] = CompactDate $now
    }
    [void]$seen.Add($notice.id)
    $showNew = $activeNewIds.Contains([string]$notice.id)
    AddNoticeRow $notice $showNew
  }
  $newNotices = @($newNotices | Sort-Object @{ Expression = { ParseNoticeDate ([string]$_.noticeDate) }; Descending = $true })
  if ($firstRun -and -not $script:Config.alert_existing_on_first_run) { $newNotices = @() }
  if ($SilentNotification) { $newNotices = @() }

  if ($newNotices.Count -gt 0) {
    $script:TotalNew += $newNotices.Count
    if ($script:Config.windows_notification_enabled) {
      $notificationNotices = @($newNotices | Select-Object -First 5)
      for ($index = 0; $index -lt $notificationNotices.Count; $index += 1) {
        $notice = $notificationNotices[$index]
        $kindText = $(if ([string]$notice.sourceType -eq "pre-spec") { $T.PreSpec } else { $notice.serviceType })
        $message = "$($notice.title)`n$kindText / $($notice.noticeAgency)`n$(BudgetText $notice)`n$($T.Close): $(FormatCloseText $notice.closeDate)"
        $position = $(if ($notificationNotices.Count -gt 1) { " $($index + 1)/$($notificationNotices.Count)" } else { "" })
        ShowWindowsNotification "$($T.NoticeAlert)$position" $message $notice.detailUrl
        if ($index -lt ($notificationNotices.Count - 1)) { Start-Sleep -Milliseconds 250 }
      }
    }
  }

  $activeNewNotices = @(
    foreach ($id in @($activeNewIds)) {
      if ($byId.ContainsKey([string]$id)) { $byId[[string]$id] }
    }
  )
  Save-JsonFile $script:StatePath ([pscustomobject]@{
    seen_ids = @($seen)
    first_seen = $firstSeen
    active_new_ids = @($activeNewIds)
    active_new_notices = $activeNewNotices
    starred_ids = @($script:StarredIds)
    starred_notices = @(
      foreach ($id in @($script:StarredIds)) {
        if ($script:StarredNotices.ContainsKey([string]$id)) { $script:StarredNotices[[string]$id] }
      }
    )
    last_checked = (CompactDate $now)
  })
  SaveStarredArchive
  $script:LastValue.Text = $now.ToString("yyyy-MM-dd HH:mm:ss")
  $script:TotalValue.Text = "$script:TotalNew$($T.CountSuffix)"
  if ($usedCrawler) {
    if ($newNotices.Count) {
      SetStatus "$($T.New) $($newNotices.Count)$($T.CountSuffix) / $($T.CrawlingUsed)"
    } elseif ($byId.Count -eq 0) {
      SetStatus (CrawlerStatusText)
    } else {
      SetStatus "$($T.NoNew) / $($T.CrawlingUsed)"
    }
  } else {
    SetStatus $(if ($newNotices.Count) { "$($T.New) $($newNotices.Count)$($T.CountSuffix)" } else { $T.NoNew })
  }
  if ($preSpecDenied) { SetStatus "$($script:StatusValue.Text) / $($T.PreSpecApiDenied)" }
}

function ShowSettingsDialog {
  $dlg = New-Object System.Windows.Forms.Form
  $dlg.Text = $T.SettingsTitle
  $dlg.StartPosition = "CenterParent"
  $dlg.Size = New-Object System.Drawing.Size(660, 600)
  $dlg.FormBorderStyle = "FixedDialog"
  $dlg.MaximizeBox = $false
  $dlg.MinimizeBox = $false

  $panel = New-Object System.Windows.Forms.TableLayoutPanel
  $panel.Dock = "Fill"
  $panel.Padding = New-Object System.Windows.Forms.Padding(14)
  $panel.ColumnCount = 2
  $panel.RowCount = 11
  $panel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 210))) | Out-Null
  $panel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
  $dlg.Controls.Add($panel)

  function AddRow($Row, $Label, $Control) {
    $panel.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 46))) | Out-Null
    $panel.Controls.Add((New-Object System.Windows.Forms.Label -Property @{ Text = $Label; Dock = "Fill"; TextAlign = "MiddleLeft" }), 0, $Row)
    $Control.Margin = New-Object System.Windows.Forms.Padding(3, 7, 3, 7)
    $panel.Controls.Add($Control, 1, $Row)
  }

  $keyBox = New-Object System.Windows.Forms.TextBox
  $keyBox.Dock = "Fill"
  $keyBox.UseSystemPasswordChar = $true
  $keyBox.Text = [string]$script:Config.service_key
  AddRow 0 $T.ServiceKey $keyBox

  $themeBox = New-Object System.Windows.Forms.ComboBox
  $themeBox.DropDownStyle = "DropDownList"
  [void]$themeBox.Items.Add($T.ThemeBlue)
  [void]$themeBox.Items.Add($T.ThemeMint)
  [void]$themeBox.Items.Add($T.ThemeCharcoal)
  switch ([string]$script:Config.theme) {
    "mint" { $themeBox.SelectedIndex = 1 }
    "charcoal" { $themeBox.SelectedIndex = 2 }
    default { $themeBox.SelectedIndex = 0 }
  }
  AddRow 1 $T.Theme $themeBox

  $typePanel = New-Object System.Windows.Forms.FlowLayoutPanel
  $typePanel.Dock = "Fill"
  $general = New-Object System.Windows.Forms.CheckBox
  $general.Text = $T.GeneralService
  $general.AutoSize = $true
  $general.Margin = New-Object System.Windows.Forms.Padding(3, 8, 18, 3)
  $general.Checked = @($script:Config.service_types) -contains $T.GeneralService
  $tech = New-Object System.Windows.Forms.CheckBox
  $tech.Text = $T.TechService
  $tech.AutoSize = $true
  $tech.Margin = New-Object System.Windows.Forms.Padding(3, 8, 3, 3)
  $tech.Checked = @($script:Config.service_types) -contains $T.TechService
  $typePanel.Controls.Add($general) | Out-Null
  $typePanel.Controls.Add($tech) | Out-Null
  AddRow 2 $T.Type $typePanel

  $interval = New-Object System.Windows.Forms.NumericUpDown
  $interval.Minimum = $(if ([bool]$script:Config.crawl_fallback_enabled) { 10 } else { 1 })
  $interval.Maximum = 1440
  $interval.Value = [decimal](EffectiveIntervalMinutes)
  AddRow 3 $T.Interval $interval

  $crawlWarning = New-Object System.Windows.Forms.Label
  $crawlWarning.Text = "$($T.CrawlIntervalWarning) $($T.CrawlBusyWarning)"
  $crawlWarning.Dock = "Fill"
  $crawlWarning.TextAlign = "MiddleLeft"
  $crawlWarning.AutoEllipsis = $true
  AddRow 4 "" $crawlWarning

  $lookback = New-Object System.Windows.Forms.NumericUpDown
  $lookback.Minimum = 1
  $lookback.Maximum = 10080
  $lookback.Value = [decimal]$script:Config.initial_lookback_minutes
  AddRow 5 $T.Lookback $lookback

  $overlap = New-Object System.Windows.Forms.NumericUpDown
  $overlap.Minimum = 0
  $overlap.Maximum = 120
  $overlap.Value = [decimal]$script:Config.overlap_minutes
  AddRow 6 $T.Overlap $overlap

  $firstRun = New-Object System.Windows.Forms.CheckBox
  $firstRun.Text = $T.FirstRun
  $firstRun.AutoSize = $true
  $firstRun.Checked = [bool]$script:Config.alert_existing_on_first_run
  AddRow 7 "" $firstRun

  $winNotify = New-Object System.Windows.Forms.CheckBox
  $winNotify.Text = $T.WinNotify
  $winNotify.AutoSize = $true
  $winNotify.Checked = [bool]$script:Config.windows_notification_enabled
  AddRow 8 "" $winNotify

  $preSpec = New-Object System.Windows.Forms.CheckBox
  $preSpec.Text = $T.IncludePreSpec
  $preSpec.AutoSize = $true
  $preSpec.Checked = [bool]$script:Config.include_pre_specs
  AddRow 9 "" $preSpec

  $buttons = New-Object System.Windows.Forms.FlowLayoutPanel
  $buttons.Dock = "Fill"
  $buttons.FlowDirection = "RightToLeft"
  $save = New-Object System.Windows.Forms.Button
  $save.Text = $T.Save
  $save.Width = 110
  $save.Height = 34
  $cancel = New-Object System.Windows.Forms.Button
  $cancel.Text = $T.Cancel
  $cancel.Width = 110
  $cancel.Height = 34
  $buttons.Controls.Add($save) | Out-Null
  $buttons.Controls.Add($cancel) | Out-Null
  $panel.Controls.Add($buttons, 0, 10)
  $panel.SetColumnSpan($buttons, 2)

  $save.Add_Click({
    $types = @()
    if ($general.Checked) { $types += $T.GeneralService }
    if ($tech.Checked) { $types += $T.TechService }
    $script:Config.service_key = $keyBox.Text.Trim()
    switch ($themeBox.SelectedIndex) {
      1 { $script:Config.theme = "mint" }
      2 { $script:Config.theme = "charcoal" }
      default { $script:Config.theme = "blue" }
    }
    $script:Config.service_types = @($types)
    $script:Config.interval_minutes = [int]$interval.Value
    $script:Config.initial_lookback_minutes = [int]$lookback.Value
    $script:Config.overlap_minutes = [int]$overlap.Value
    $script:Config.alert_existing_on_first_run = $firstRun.Checked
    $script:Config.windows_notification_enabled = $winNotify.Checked
    $script:Config.include_pre_specs = $preSpec.Checked
    $coerced = EnforceIntervalPolicy
    SaveConfig
    ApplyTheme
    if ($coerced) { SetStatus $T.CrawlIntervalWarning }
    $dlg.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $dlg.Close()
  })
  $cancel.Add_Click({ $dlg.Close() })
  $dlg.ShowDialog($script:Form) | Out-Null
}

$defaultConfig = Get-DefaultConfig
$loadedConfig = Load-JsonFile $script:ConfigPath $defaultConfig
$script:Config = To-Hashtable $loadedConfig
foreach ($key in $defaultConfig.Keys) { if (-not $script:Config.ContainsKey($key)) { $script:Config[$key] = $defaultConfig[$key] } }
if ([int]$script:Config.timeout_seconds -lt 45) { $script:Config.timeout_seconds = 45 }
if ([string]$script:Config.search_mode -eq "bulk" -and [int]$script:Config.num_of_rows -lt 500) {
  $script:Config.num_of_rows = 999
}
[void](EnforceIntervalPolicy)
InitializeStarredState

$script:Form = New-Object System.Windows.Forms.Form
$script:Form.Text = $T.AppTitle
$script:Form.StartPosition = "CenterScreen"
$script:Form.Size = New-Object System.Drawing.Size(1500, 800)
$script:Form.MinimumSize = New-Object System.Drawing.Size(1180, 680)

$main = New-Object System.Windows.Forms.TableLayoutPanel
$main.Dock = "Fill"
$main.RowCount = 4
$main.ColumnCount = 1
$main.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 112))) | Out-Null
$main.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 158))) | Out-Null
$main.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$main.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 86))) | Out-Null
$script:Form.Controls.Add($main)

$header = New-Object System.Windows.Forms.TableLayoutPanel
$header.Dock = "Fill"
$header.ColumnCount = 2
$header.Padding = New-Object System.Windows.Forms.Padding(14, 10, 14, 6)
$header.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$header.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 980))) | Out-Null
$main.Controls.Add($header, 0, 0)

$titlePanel = New-Object System.Windows.Forms.TableLayoutPanel
$titlePanel.Dock = "Fill"
$titlePanel.RowCount = 2
$titlePanel.ColumnCount = 1
$titlePanel.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 64))) | Out-Null
$titlePanel.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 36))) | Out-Null
$header.Controls.Add($titlePanel, 0, 0)

$script:TitleLabel = New-Object System.Windows.Forms.Label
$script:TitleLabel.Text = $T.AppTitle
$script:TitleLabel.Dock = "Fill"
$script:TitleLabel.TextAlign = "BottomLeft"
$titlePanel.Controls.Add($script:TitleLabel, 0, 0)

$script:KakaoChatUrl = "https://open.kakao.com/o/sUEJlIAi"
$script:MetaLabel = New-Object System.Windows.Forms.LinkLabel
$metaPrefix = "v$script:AppVersion  |  $($T.Author)  |  $($T.KakaoChat) : "
$script:MetaLabel.Text = "$metaPrefix$script:KakaoChatUrl"
$script:MetaLabel.LinkArea = New-Object System.Windows.Forms.LinkArea($metaPrefix.Length, $script:KakaoChatUrl.Length)
$script:MetaLabel.Dock = "Fill"
$script:MetaLabel.TextAlign = "TopLeft"
$script:MetaLabel.LinkBehavior = [System.Windows.Forms.LinkBehavior]::HoverUnderline
$script:MetaLabel.Add_LinkClicked({ Start-Process $script:KakaoChatUrl })
$titlePanel.Controls.Add($script:MetaLabel, 0, 1)

$actions = New-Object System.Windows.Forms.FlowLayoutPanel
$actions.Dock = "Fill"
$actions.FlowDirection = "RightToLeft"
$header.Controls.Add($actions, 1, 0)

function NewButton($Text, $Width) {
  $btn = New-Object System.Windows.Forms.Button
  $btn.Text = $Text
  $btn.Width = $Width
  $btn.Height = 42
  $btn.Margin = New-Object System.Windows.Forms.Padding(4)
  $btn.Font = New-Object System.Drawing.Font("Malgun Gothic", 9.5, [System.Drawing.FontStyle]::Bold)
  return $btn
}

$stopButton = NewButton $T.Stop 74
$script:StartButton = NewButton $T.Start 118
$testButton = NewButton $T.Test 118
$helpButton = NewButton $T.Help 118
$script:UpdateCheckButton = NewButton $T.UpdateCheck 132
$script:UpdateCheckButton.TextAlign = [System.Drawing.ContentAlignment]::BottomCenter
$script:UpdateCheckButton.Padding = New-Object System.Windows.Forms.Padding(0, 0, 0, 2)
$script:UpdateBadge = New-Object System.Windows.Forms.Label
$script:UpdateBadge.AutoSize = $true
$script:UpdateBadge.Font = New-Object System.Drawing.Font("Malgun Gothic", 7, [System.Drawing.FontStyle]::Bold)
$script:UpdateBadge.Padding = New-Object System.Windows.Forms.Padding(3, 1, 3, 1)
$script:UpdateBadge.Location = New-Object System.Drawing.Point(68, 1)
$script:UpdateBadge.Anchor = "Top, Right"
$script:UpdateBadge.Cursor = [System.Windows.Forms.Cursors]::Hand
$script:UpdateBadge.Visible = $false
$script:UpdateBadge.Add_Click({ $script:UpdateCheckButton.PerformClick() })
$script:UpdateCheckButton.Controls.Add($script:UpdateBadge)
$updateHistoryButton = NewButton $T.UpdateHistory 118
$settingsButton = NewButton $T.Settings 82
$recentButton = NewButton $T.Recent 164
@($stopButton, $script:StartButton, $testButton, $helpButton, $script:UpdateCheckButton, $updateHistoryButton, $settingsButton, $recentButton) | ForEach-Object { $actions.Controls.Add($_) | Out-Null }

$keywordPanel = New-Object System.Windows.Forms.GroupBox
$keywordPanel.Text = $T.Keywords
$keywordPanel.Dock = "Fill"
$keywordPanel.Padding = New-Object System.Windows.Forms.Padding(12)
$main.Controls.Add($keywordPanel, 0, 1)

$keywordLayout = New-Object System.Windows.Forms.TableLayoutPanel
$keywordLayout.Dock = "Fill"
$keywordLayout.ColumnCount = 2
$keywordLayout.RowCount = 1
$keywordLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 50))) | Out-Null
$keywordLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 50))) | Out-Null
$keywordLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$keywordPanel.Controls.Add($keywordLayout)

$script:KeywordList = New-Object System.Windows.Forms.ListBox
$script:KeywordList.Dock = "Fill"
$script:KeywordList.SelectionMode = "One"
$script:KeywordList.MultiColumn = $true
$script:KeywordList.IntegralHeight = $false
$script:KeywordList.HorizontalScrollbar = $false
$script:KeywordList.ItemHeight = 16
$script:KeywordList.ColumnWidth = 170
$script:KeywordList.Add_SizeChanged({ UpdateKeywordListLayout })
foreach ($kw in @($script:Config.keywords)) { [void]$script:KeywordList.Items.Add([string]$kw) }
$keywordLayout.Controls.Add($script:KeywordList, 0, 0)
UpdateStartButtonState

$keywordAddLayout = New-Object System.Windows.Forms.TableLayoutPanel
$keywordAddLayout.Dock = "Fill"
$keywordAddLayout.Margin = New-Object System.Windows.Forms.Padding(8, 0, 0, 0)
$keywordAddLayout.ColumnCount = 2
$keywordAddLayout.RowCount = 4
$keywordAddLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$keywordAddLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 110))) | Out-Null
$keywordAddLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 24))) | Out-Null
$keywordAddLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 36))) | Out-Null
$keywordAddLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 24))) | Out-Null
$keywordAddLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$keywordLayout.Controls.Add($keywordAddLayout, 1, 0)

$keywordHelp = New-Object System.Windows.Forms.Label
$keywordHelp.Text = $T.KeywordAddHint
$keywordHelp.Dock = "Fill"
$keywordHelp.TextAlign = "MiddleLeft"
$keywordAddLayout.Controls.Add($keywordHelp, 0, 0)
$keywordAddLayout.SetColumnSpan($keywordHelp, 2)

$keywordInput = New-Object System.Windows.Forms.TextBox
$keywordInput.Dock = "Fill"
$keywordInput.Margin = New-Object System.Windows.Forms.Padding(0, 4, 6, 4)
$keywordAddLayout.Controls.Add($keywordInput, 0, 1)

$keywordExample = New-Object System.Windows.Forms.Label
$keywordExample.Text = $T.KeywordExample
$keywordExample.Dock = "Fill"
$keywordExample.TextAlign = "MiddleLeft"
$keywordAddLayout.Controls.Add($keywordExample, 0, 2)

$script:KeywordCountWarningLabel = New-Object System.Windows.Forms.Label
$script:KeywordCountWarningLabel.Text = $T.KeywordCountWarning
$script:KeywordCountWarningLabel.Dock = "Fill"
$script:KeywordCountWarningLabel.TextAlign = "MiddleLeft"
$script:KeywordCountWarningLabel.AutoEllipsis = $false
$script:KeywordCountWarningLabel.Font = New-Object System.Drawing.Font("Malgun Gothic", 7.5, [System.Drawing.FontStyle]::Bold)
$keywordAddLayout.Controls.Add($script:KeywordCountWarningLabel, 0, 3)
$keywordAddLayout.SetColumnSpan($script:KeywordCountWarningLabel, 2)

$addKeyword = NewButton $T.Add 92
$deleteKeyword = NewButton $T.Delete 92
$addKeyword.Height = 30
$addKeyword.Margin = New-Object System.Windows.Forms.Padding(4, 2, 4, 2)
$deleteKeyword.Height = 22
$deleteKeyword.Margin = New-Object System.Windows.Forms.Padding(4, 1, 4, 1)
$keywordAddLayout.Controls.Add($addKeyword, 1, 1)
$keywordAddLayout.Controls.Add($deleteKeyword, 1, 2)

$resultsLayout = New-Object System.Windows.Forms.TableLayoutPanel
$resultsLayout.Dock = "Fill"
$resultsLayout.RowCount = 3
$resultsLayout.ColumnCount = 1
$resultsLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 40))) | Out-Null
$resultsLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 25))) | Out-Null
$resultsLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$main.Controls.Add($resultsLayout, 0, 2)

$resultSearchPanel = New-Object System.Windows.Forms.TableLayoutPanel
$resultSearchPanel.Dock = "Fill"
$resultSearchPanel.Padding = New-Object System.Windows.Forms.Padding(8, 5, 8, 5)
$resultSearchPanel.ColumnCount = 4
$resultSearchPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 170))) | Out-Null
$resultSearchPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$resultSearchPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 90))) | Out-Null
$resultSearchPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 130))) | Out-Null
$resultSearchPanel.Controls.Add((New-Object System.Windows.Forms.Label -Property @{ Text = $T.ResultSearch; Dock = "Fill"; TextAlign = "MiddleLeft" }), 0, 0)
$script:ResultSearchBox = New-Object System.Windows.Forms.TextBox
$script:ResultSearchBox.Dock = "Fill"
$script:ResultSearchBox.Margin = New-Object System.Windows.Forms.Padding(3, 4, 3, 4)
$resultSearchPanel.Controls.Add($script:ResultSearchBox, 1, 0)
$clearResultSearch = NewButton $T.Clear 76
$clearResultSearch.Height = 30
$clearResultSearch.Margin = New-Object System.Windows.Forms.Padding(4, 1, 4, 1)
$resultSearchPanel.Controls.Add($clearResultSearch, 2, 0)
$excelExportButton = NewButton $T.ExcelExport 116
$excelExportButton.Height = 30
$excelExportButton.Margin = New-Object System.Windows.Forms.Padding(4, 1, 4, 1)
$resultSearchPanel.Controls.Add($excelExportButton, 3, 0)
$resultsLayout.Controls.Add($resultSearchPanel, 0, 0)

$script:ResetWarningLabel = New-Object System.Windows.Forms.Label
$script:ResetWarningLabel.Text = $T.ResultResetWarning
$script:ResetWarningLabel.Dock = "Fill"
$script:ResetWarningLabel.Padding = New-Object System.Windows.Forms.Padding(12, 0, 8, 0)
$script:ResetWarningLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$script:ResetWarningLabel.Font = New-Object System.Drawing.Font("Malgun Gothic", 8.5, [System.Drawing.FontStyle]::Bold)
$resultsLayout.Controls.Add($script:ResetWarningLabel, 0, 1)

$script:Grid = New-Object System.Windows.Forms.DataGridView
$script:Grid.Dock = "Fill"
$script:Grid.AllowUserToAddRows = $false
$script:Grid.ReadOnly = $true
$script:Grid.SelectionMode = "FullRowSelect"
$script:Grid.AutoSizeColumnsMode = "Fill"
$script:Grid.RowHeadersVisible = $false
$script:Grid.AllowUserToResizeRows = $false
$script:Grid.AutoSizeRowsMode = [System.Windows.Forms.DataGridViewAutoSizeRowsMode]::None
$script:Grid.Font = New-Object System.Drawing.Font("Malgun Gothic", 9, [System.Drawing.FontStyle]::Regular)
$script:Grid.RowTemplate.MinimumHeight = 24
$script:Grid.RowTemplate.Height = 24
$script:Grid.DefaultCellStyle.Padding = New-Object System.Windows.Forms.Padding(1, 1, 1, 1)
$script:Grid.Columns.Add("star", $T.Favorite) | Out-Null
$script:Grid.Columns.Add("new", $T.Status) | Out-Null
$script:Grid.Columns.Add("title", $T.Title) | Out-Null
$script:Grid.Columns.Add("agency", $T.Agency) | Out-Null
$script:Grid.Columns.Add("budget", $T.BudgetEstimate) | Out-Null
$script:Grid.Columns.Add("posted", $T.Posted) | Out-Null
$script:Grid.Columns.Add("close", $T.Close) | Out-Null
$script:Grid.Columns.Add("keyword", $T.SearchKeyword) | Out-Null
$script:Grid.Columns.Add("url", $T.Link) | Out-Null
$script:Grid.Columns.Add("internalId", "internalId") | Out-Null
$script:Grid.Columns.Add("sourceType", "sourceType") | Out-Null
$script:Grid.Columns.Add("closeRaw", "closeRaw") | Out-Null
$script:Grid.Columns["star"].FillWeight = 32
$script:Grid.Columns["star"].MinimumWidth = 48
$script:Grid.Columns["new"].FillWeight = 72
$script:Grid.Columns["title"].FillWeight = 260
$script:Grid.Columns["agency"].FillWeight = 110
$script:Grid.Columns["budget"].FillWeight = 100
$script:Grid.Columns["posted"].FillWeight = 92
$script:Grid.Columns["close"].FillWeight = 115
$script:Grid.Columns["keyword"].FillWeight = 72
$script:Grid.Columns["url"].Visible = $false
$script:Grid.Columns["internalId"].Visible = $false
$script:Grid.Columns["sourceType"].Visible = $false
$script:Grid.Columns["closeRaw"].Visible = $false
$script:Grid.Add_CellClick({
  if ($_.RowIndex -ge 0 -and $_.ColumnIndex -eq $script:Grid.Columns["star"].Index) {
    ToggleStarredRow $script:Grid.Rows[$_.RowIndex]
  }
})
$script:Grid.Add_CellDoubleClick({
  if ($_.RowIndex -ge 0) {
    if ($_.ColumnIndex -eq $script:Grid.Columns["star"].Index) { return }
    $url = [string]$script:Grid.Rows[$_.RowIndex].Cells["url"].Value
    if ($url -like "prespec:*") {
      $preSpecNo = $url.Substring("prespec:".Length)
      $helper = Join-Path $script:AppDir "show_prespec_detail.ps1"
      if (Test-Path -LiteralPath $helper) {
        Start-Process -FilePath "powershell.exe" -ArgumentList @(
          "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$helper`"", "-PreSpecNo", "`"$preSpecNo`""
        ) | Out-Null
      }
    } elseif ($url) {
      Start-Process $url
    }
  }
})
$script:ResultSearchBox.Add_TextChanged({ ApplyResultFilter })
$clearResultSearch.Add_Click({ $script:ResultSearchBox.Clear(); ApplyResultFilter })
$excelExportButton.Add_Click({ ExportVisibleNoticesToExcel })
$resultsLayout.Controls.Add($script:Grid, 0, 2)

$startupState = Load-JsonFile $script:StatePath ([pscustomobject]@{})
$startupActiveNewIds = New-Object "System.Collections.Generic.HashSet[string]"
if ($startupState.PSObject.Properties["active_new_ids"]) {
  foreach ($id in @($startupState.active_new_ids)) {
    if ($id) { [void]$startupActiveNewIds.Add([string]$id) }
  }
}
foreach ($notice in @($script:StarredNotices.Values | Sort-Object @{ Expression = { ParseNoticeDate ([string]$_.noticeDate) }; Ascending = $true })) {
  AddNoticeRow $notice ($startupActiveNewIds.Contains([string]$notice.id))
}

$status = New-Object System.Windows.Forms.TableLayoutPanel
$status.Dock = "Fill"
$status.ColumnCount = 8
$status.RowCount = 2
$status.Padding = New-Object System.Windows.Forms.Padding(14, 8, 14, 8)
1..8 | ForEach-Object { $status.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 12.5))) | Out-Null }
$status.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 54))) | Out-Null
$status.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 46))) | Out-Null
$main.Controls.Add($status, 0, 3)

$status.Controls.Add((New-Object System.Windows.Forms.Label -Property @{ Text = $T.Status; Dock = "Fill"; TextAlign = "MiddleLeft" }), 0, 0)
$script:StatusValue = New-Object System.Windows.Forms.Label
$script:StatusValue.Text = $T.Ready
$script:StatusValue.Dock = "Fill"
$script:StatusValue.Font = New-Object System.Drawing.Font("Malgun Gothic", 10, [System.Drawing.FontStyle]::Bold)
$script:StatusValue.AutoEllipsis = $true
$status.Controls.Add($script:StatusValue, 1, 0)
$status.SetColumnSpan($script:StatusValue, 7)

$status.Controls.Add((New-Object System.Windows.Forms.Label -Property @{ Text = $T.LastChecked; Dock = "Fill"; TextAlign = "MiddleLeft" }), 0, 1)
$script:LastValue = New-Object System.Windows.Forms.Label
$script:LastValue.Text = "-"
$script:LastValue.Dock = "Fill"
$status.Controls.Add($script:LastValue, 1, 1)
$status.Controls.Add((New-Object System.Windows.Forms.Label -Property @{ Text = $T.NextCheck; Dock = "Fill"; TextAlign = "MiddleLeft" }), 2, 1)
$script:NextValue = New-Object System.Windows.Forms.Label
$script:NextValue.Text = "-"
$script:NextValue.Dock = "Fill"
$script:NextValue.Font = New-Object System.Drawing.Font("Malgun Gothic", 9, [System.Drawing.FontStyle]::Bold)
$status.Controls.Add($script:NextValue, 3, 1)
$status.Controls.Add((New-Object System.Windows.Forms.Label -Property @{ Text = $T.DataMode; Dock = "Fill"; TextAlign = "MiddleLeft" }), 4, 1)
$script:ModeValue = New-Object System.Windows.Forms.Label
$script:ModeValue.Text = $T.ApiThenCrawlMode
$script:ModeValue.Dock = "Fill"
$script:ModeValue.AutoEllipsis = $true
$status.Controls.Add($script:ModeValue, 5, 1)
$status.Controls.Add((New-Object System.Windows.Forms.Label -Property @{ Text = $T.TotalNew; Dock = "Fill"; TextAlign = "MiddleLeft" }), 6, 1)
$script:TotalValue = New-Object System.Windows.Forms.Label
$script:TotalValue.Text = "0$($T.CountSuffix)"
$script:TotalValue.Dock = "Fill"
$status.Controls.Add($script:TotalValue, 7, 1)

$timer = New-Object System.Windows.Forms.Timer
$timer.Add_Tick({
  try {
    $script:CancelRequested = $false
    ClearNextCheck
    CheckNotices $false $false
    SetNextCheckFromNow
  } catch {
    HandleCheckFailure $_.Exception
    if ([string]$_.Exception.Message -ne $T.Cancelled) { SetNextCheckFromNow }
  }
})

$countdownTimer = New-Object System.Windows.Forms.Timer
$countdownTimer.Interval = 1000
$countdownTimer.Add_Tick({ UpdateCountdownLabel })
$countdownTimer.Start()

$startupUpdateTimer = New-Object System.Windows.Forms.Timer
$startupUpdateTimer.Interval = 2500
$startupUpdateTimer.Add_Tick({
  $startupUpdateTimer.Stop()
  CheckForAppUpdate $false
})
$startupUpdateTimer.Start()

$addKeyword.Add_Click({
  $kw = $keywordInput.Text.Trim()
  if ($kw -and -not $script:KeywordList.Items.Contains($kw)) {
    [void]$script:KeywordList.Items.Add($kw)
    $keywordInput.Clear()
    SaveConfig
    UpdateStartButtonState
  }
})
$keywordInput.Add_KeyDown({ if ($_.KeyCode -eq "Enter") { $addKeyword.PerformClick(); $_.SuppressKeyPress = $true } })
$deleteKeyword.Add_Click({
  if ($script:KeywordList.SelectedIndex -ge 0) {
    $script:KeywordList.Items.RemoveAt($script:KeywordList.SelectedIndex)
    SaveConfig
    UpdateStartButtonState
  }
})

$settingsButton.Add_Click({ ShowSettingsDialog })
$script:UpdateCheckButton.Add_Click({ CheckForAppUpdate $true })
$updateHistoryButton.Add_Click({
  $history = Join-Path $script:AppDir "update_history.html"
  if (Test-Path -LiteralPath $history) { Start-Process $history }
})
$helpButton.Add_Click({
  $guide = Join-Path $script:AppDir "guide.html"
  if (Test-Path -LiteralPath $guide) {
    Start-Process $guide
  } else {
    [System.Windows.Forms.MessageBox]::Show("$($T.HelpText)`r`n`r`n$($T.PreSpecHelp)", $T.Help, "OK", "Information") | Out-Null
  }
})
$testButton.Add_Click({ ShowWindowsNotification "$($T.AppTitle) $($T.Test)" $T.TestMessage "https://www.g2b.go.kr/" })
$recentButton.Add_Click({ try { $script:CancelRequested = $false; CheckNotices $true $true } catch { HandleCheckFailure $_.Exception } })
$script:StartButton.Add_Click({
  try {
    $coerced = EnforceIntervalPolicy
    $script:CancelRequested = $false
    SaveConfig
    $timer.Interval = (EffectiveIntervalMinutes) * 60000
    $timer.Start()
    SetStatus $(if ($coerced) { "$($T.Running) - $($T.CrawlIntervalWarning)" } else { $T.Running })
    try {
      ClearNextCheck
      CheckNotices $false $false
      SetNextCheckFromNow
    } catch {
      HandleCheckFailure $_.Exception
      if ([string]$_.Exception.Message -ne $T.Cancelled) { SetNextCheckFromNow }
    }
  } catch {
    HandleCheckFailure $_.Exception
  }
})
$stopButton.Add_Click({ RequestStop })
$script:Form.Add_FormClosing({
  RequestStop
  SaveConfig
  SaveStarredArchive
  $countdownTimer.Stop()
  $startupUpdateTimer.Stop()
  if ($script:SingleInstanceMutex) {
    try { $script:SingleInstanceMutex.ReleaseMutex() } catch {}
    $script:SingleInstanceMutex.Dispose()
    $script:SingleInstanceMutex = $null
  }
})

[System.Windows.Forms.Application]::EnableVisualStyles()
ApplyTheme
try {
  [System.Windows.Forms.Application]::Run($script:Form)
} finally {
  if ($script:SingleInstanceMutex) {
    try { $script:SingleInstanceMutex.ReleaseMutex() } catch {}
    $script:SingleInstanceMutex.Dispose()
    $script:SingleInstanceMutex = $null
  }
}
