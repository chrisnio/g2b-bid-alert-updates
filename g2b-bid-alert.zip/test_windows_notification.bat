@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0show_windows_notification.ps1" -Title "나라장터 공고 모니터 테스트" -Message "Windows 알림이 정상 작동합니다.`n배정예산: 123,456,789원" -Url "https://www.g2b.go.kr/"
