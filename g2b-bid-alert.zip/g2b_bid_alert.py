#!/usr/bin/env python3
"""
G2B bid notice keyword monitor.

Runs a polling loop against the Nara Market (G2B) bid notice API and shows a
desktop popup when new matching service notices are found.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any


API_URL = "https://apis.data.go.kr/1230000/ad/BidPublicInfoService/getBidPblancListInfoServcPPSSrch"
DEFAULT_CONFIG = "config.json"
DEFAULT_STATE = "seen_notices.json"


@dataclass
class Notice:
    keyword: str
    bid_no: str
    bid_ord: str
    title: str
    service_type: str
    notice_kind: str
    notice_agency: str
    demand_agency: str
    notice_datetime: str
    close_datetime: str
    budget: str
    estimated_price: str
    detail_url: str

    @property
    def notice_id(self) -> str:
        return f"{self.bid_no}-{self.bid_ord}"

    def short_text(self) -> str:
        money = format_money(self.budget) if self.budget else "-"
        close_dt = self.close_datetime or "-"
        return (
            f"[{self.keyword}] {self.title}\n"
            f"공고번호: {self.notice_id} / {self.service_type} / {self.notice_kind}\n"
            f"기관: {self.notice_agency} / 수요기관: {self.demand_agency}\n"
            f"공고일시: {self.notice_datetime} / 마감: {close_dt}\n"
            f"배정예산: {money}\n"
            f"상세: {self.detail_url}"
        )


def load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def save_json(path: Path, data: Any) -> None:
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def parse_kst_datetime(value: str) -> datetime | None:
    if not value:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y%m%d%H%M"):
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            pass
    return None


def yyyymmddhhmm(dt: datetime) -> str:
    return dt.strftime("%Y%m%d%H%M")


def normalize_items(raw_items: Any) -> list[dict[str, Any]]:
    if not raw_items:
        return []
    if isinstance(raw_items, list):
        return raw_items
    if isinstance(raw_items, dict):
        return [raw_items]
    return []


def query_keyword(config: dict[str, Any], keyword: str, start: datetime, end: datetime) -> list[dict[str, Any]]:
    params = {
        "serviceKey": config["service_key"],
        "pageNo": "1",
        "numOfRows": str(config.get("num_of_rows", 100)),
        "type": "json",
        "inqryDiv": "1",
        "inqryBgnDt": yyyymmddhhmm(start),
        "inqryEndDt": yyyymmddhhmm(end),
        "bidNtceNm": keyword,
    }
    url = f"{API_URL}?{urllib.parse.urlencode(params, safe='')}"
    req = urllib.request.Request(url, headers={"User-Agent": "g2b-bid-alert/1.0"})

    with urllib.request.urlopen(req, timeout=int(config.get("timeout_seconds", 20))) as resp:
        payload = json.loads(resp.read().decode("utf-8"))

    if "nkoneps.com.response.ResponseError" in payload:
        header = payload["nkoneps.com.response.ResponseError"].get("header", {})
        raise RuntimeError(f"API error {header.get('resultCode')}: {header.get('resultMsg')}")

    header = payload.get("response", {}).get("header", {})
    if header.get("resultCode") != "00":
        raise RuntimeError(f"API error {header.get('resultCode')}: {header.get('resultMsg')}")

    body = payload.get("response", {}).get("body", {})
    return normalize_items(body.get("items"))


def notice_from_item(keyword: str, item: dict[str, Any]) -> Notice:
    return Notice(
        keyword=keyword,
        bid_no=str(item.get("bidNtceNo", "")),
        bid_ord=str(item.get("bidNtceOrd", "")),
        title=str(item.get("bidNtceNm", "")).strip(),
        service_type=str(item.get("srvceDivNm", "")),
        notice_kind=str(item.get("ntceKindNm", "")),
        notice_agency=str(item.get("ntceInsttNm", "")),
        demand_agency=str(item.get("dminsttNm", "")),
        notice_datetime=str(item.get("bidNtceDt") or item.get("rgstDt") or ""),
        close_datetime=str(item.get("bidClseDt") or item.get("opengDt") or ""),
        budget=str(item.get("asignBdgtAmt", "")),
        estimated_price=str(item.get("presmptPrce", "")),
        detail_url=str(item.get("bidNtceDtlUrl") or item.get("bidNtceUrl") or ""),
    )


def is_cancelled_notice(notice: Notice) -> bool:
    return "취소" in notice.notice_kind.strip()


def collect_notices(config: dict[str, Any], start: datetime, end: datetime) -> list[Notice]:
    allowed_service_types = set(config.get("service_types", ["일반용역", "기술용역"]))
    notices_by_id: dict[str, Notice] = {}

    for keyword in config.get("keywords", []):
        items = query_keyword(config, str(keyword), start, end)
        for item in items:
            notice = notice_from_item(str(keyword), item)
            if not notice.bid_no or not notice.bid_ord:
                continue
            if is_cancelled_notice(notice):
                continue
            if notice.service_type not in allowed_service_types:
                continue
            notices_by_id.setdefault(notice.notice_id, notice)

    return sorted(
        notices_by_id.values(),
        key=lambda n: parse_kst_datetime(n.notice_datetime) or datetime.min,
    )


def format_money(value: str) -> str:
    try:
        return f"{int(value):,}원"
    except (TypeError, ValueError):
        return str(value)


def notice_budget_text(notice: Notice) -> str:
    if notice.budget:
        return f"배정예산: {format_money(notice.budget)}"
    if notice.estimated_price:
        return f"추정가격: {format_money(notice.estimated_price)}"
    return "예산: -"


def build_alert_text(notices: list[Notice]) -> str:
    header = f"나라장터 신규 용역 공고 {len(notices)}건"
    body = "\n\n".join(n.short_text() for n in notices)
    return f"{header}\n\n{body}"


def show_popup(title: str, message: str) -> None:
    try:
        import tkinter as tk
        from tkinter import messagebox

        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        messagebox.showinfo(title, message)
        root.destroy()
    except Exception:
        # Console output remains the reliable fallback for scheduled runs.
        pass


def show_windows_notification(title: str, message: str, url: str = "") -> None:
    if os.name != "nt":
        return

    script_path = Path(__file__).with_name("show_windows_notification.ps1")
    if not script_path.exists():
        return

    try:
        subprocess.Popen(
            [
                "powershell.exe",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-WindowStyle",
                "Hidden",
                "-File",
                str(script_path),
                "-Title",
                title,
                "-Message",
                message,
                "-Url",
                url or "",
            ],
            cwd=str(script_path.parent),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except Exception:
        pass


def notify(config: dict[str, Any], notices: list[Notice]) -> None:
    if not notices:
        return
    message = build_alert_text(notices)
    print(message, flush=True)

    log_path = Path(config.get("log_file", "alerts.log"))
    with log_path.open("a", encoding="utf-8") as f:
        f.write(f"\n[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}]\n{message}\n")

    if config.get("popup_enabled", True):
        max_popup_chars = int(config.get("max_popup_chars", 3500))
        popup_message = message
        if len(popup_message) > max_popup_chars:
            popup_message = popup_message[:max_popup_chars] + "\n\n...자세한 내용은 alerts.log를 확인하세요."
        show_popup("나라장터 신규 공고 알림", popup_message)

    if config.get("windows_notification_enabled", True):
        first = notices[0]
        budget_text = notice_budget_text(first)
        if len(notices) == 1:
            toast_message = f"{first.title}\n{first.service_type} / {first.notice_agency}\n{budget_text}\n마감: {first.close_datetime or '-'}"
        else:
            toast_message = f"{first.title}\n{budget_text}\n외 {len(notices) - 1}건의 신규 공고가 있습니다."
        show_windows_notification(
            f"나라장터 신규 공고 {len(notices)}건",
            toast_message,
            first.detail_url,
        )


def validate_config(config: dict[str, Any]) -> None:
    if not config.get("service_key") or config["service_key"] == "PUT_YOUR_SERVICE_KEY_HERE":
        raise ValueError("config.json의 service_key에 공공데이터포털 인증키를 입력하세요.")
    if not config.get("keywords"):
        raise ValueError("config.json의 keywords에 감시할 키워드를 1개 이상 입력하세요.")
    if int(config.get("interval_minutes", 30)) < 1:
        raise ValueError("interval_minutes는 1 이상이어야 합니다.")


def run_once(config_path: Path, state_path: Path, alert_existing_on_first_run: bool | None = None) -> int:
    config = load_json(config_path, {})
    validate_config(config)

    state = load_json(state_path, {"seen_ids": [], "last_checked": ""})
    seen_ids = set(state.get("seen_ids", []))
    now = datetime.now()

    last_checked = parse_kst_datetime(state.get("last_checked", ""))
    if last_checked:
        start = last_checked - timedelta(minutes=int(config.get("overlap_minutes", 3)))
    else:
        start = now - timedelta(minutes=int(config.get("initial_lookback_minutes", 4320)))

    notices = collect_notices(config, start, now)
    new_notices = [n for n in notices if n.notice_id not in seen_ids]

    first_run = not bool(seen_ids) and not state.get("last_checked")
    if alert_existing_on_first_run is None:
        alert_existing_on_first_run = bool(config.get("alert_existing_on_first_run", True))

    if first_run and not alert_existing_on_first_run:
        new_notices = []

    notify(config, new_notices)

    for notice in notices:
        seen_ids.add(notice.notice_id)

    state["seen_ids"] = sorted(seen_ids)
    state["last_checked"] = yyyymmddhhmm(now)
    save_json(state_path, state)

    if not new_notices:
        print(f"[{now.strftime('%Y-%m-%d %H:%M:%S')}] 신규 공고 없음", flush=True)
    return len(new_notices)


def main() -> int:
    parser = argparse.ArgumentParser(description="나라장터 용역 입찰공고 키워드 알림")
    parser.add_argument("--config", default=DEFAULT_CONFIG, help="설정 파일 경로")
    parser.add_argument("--state", default=DEFAULT_STATE, help="중복 알림 방지 상태 파일 경로")
    parser.add_argument("--once", action="store_true", help="한 번만 조회하고 종료")
    args = parser.parse_args()

    config_path = Path(args.config)
    state_path = Path(args.state)

    if args.once:
        run_once(config_path, state_path)
        return 0

    while True:
        try:
            config = load_json(config_path, {})
            interval = int(config.get("interval_minutes", 30))
            run_once(config_path, state_path)
        except KeyboardInterrupt:
            print("종료합니다.", flush=True)
            return 0
        except (ValueError, RuntimeError, urllib.error.URLError, json.JSONDecodeError) as exc:
            print(f"[오류] {exc}", file=sys.stderr, flush=True)
            interval = 5

        time.sleep(max(1, interval) * 60)


if __name__ == "__main__":
    raise SystemExit(main())
