param(
  [Parameter(Mandatory = $true)][string]$PreSpecNo,
  [string]$ConfigPath = ""
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$appDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $ConfigPath) { $ConfigPath = Join-Path $appDir "config.json" }

Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class ConsoleWindow {
  [DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
}
"@
[void][ConsoleWindow]::ShowWindow([ConsoleWindow]::GetConsoleWindow(), 0)

function U([string]$Text) {
  [Text.RegularExpressions.Regex]::Replace($Text, "\\u([0-9a-fA-F]{4})", {
    param($match)
    [char][Convert]::ToInt32($match.Groups[1].Value, 16)
  })
}

function Open-SlowG2b {
  $helper = Join-Path $appDir "open_g2b_prespec.ps1"
  if (-not (Test-Path -LiteralPath $helper)) { return }
  Start-Process -FilePath "powershell.exe" -WindowStyle Hidden -ArgumentList @(
    "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$helper`"",
    "-PreSpecNo", "`"$PreSpecNo`""
  ) | Out-Null
}

function Format-Money([string]$Value) {
  $digits = $Value -replace "\D", ""
  if (-not $digits) { return "-" }
  try { return ("{0:N0}" -f [decimal]$digits) + (U "\uc6d0") } catch { return "$Value $(U "\uc6d0")" }
}

function Query-PreSpec {
  if (-not (Test-Path -LiteralPath $ConfigPath)) { throw (U "config.json\uc744 \ucc3e\uc744 \uc218 \uc5c6\uc2b5\ub2c8\ub2e4.") }
  $config = Get-Content -LiteralPath $ConfigPath -Encoding UTF8 -Raw | ConvertFrom-Json
  if (-not $config.service_key -or $config.service_key -eq "PUT_YOUR_SERVICE_KEY_HERE") {
    throw (U "\uacf5\uacf5\ub370\uc774\ud130\ud3ec\ud138 \uc778\uc99d\ud0a4\uac00 \uc124\uc815\ub418\uc9c0 \uc54a\uc558\uc2b5\ub2c8\ub2e4.")
  }

  $params = [ordered]@{
    serviceKey = [string]$config.service_key
    pageNo = "1"
    numOfRows = "10"
    type = "json"
    inqryDiv = "2"
    bfSpecRgstNo = $PreSpecNo
  }
  $query = ($params.GetEnumerator() | ForEach-Object {
    [Uri]::EscapeDataString($_.Key) + "=" + [Uri]::EscapeDataString([string]$_.Value)
  }) -join "&"
  $url = "https://apis.data.go.kr/1230000/ao/HrcspSsstndrdInfoService/getPublicPrcureThngInfoServcPPSSrch?$query"
  $response = Invoke-RestMethod -Uri $url -Method Get -TimeoutSec 20 -Headers @{
    "User-Agent" = "g2b-bid-alert-prespec-detail/1.0"
  }
  if ($response.'nkoneps.com.response.ResponseError') {
    $header = $response.'nkoneps.com.response.ResponseError'.header
    throw (U "API \uc624\ub958 $($header.resultCode): $($header.resultMsg)")
  }
  if ($response.response.header.resultCode -ne "00") {
    throw (U "API \uc624\ub958 $($response.response.header.resultCode): $($response.response.header.resultMsg)")
  }

  $items = @($response.response.body.items)
  return $items | Where-Object { [string]$_.bfSpecRgstNo -eq $PreSpecNo } | Select-Object -First 1
}

try {
  $item = Query-PreSpec
  if (-not $item) { throw (U "\ud574\ub2f9 \uc0ac\uc804\uaddc\uaca9 \uc815\ubcf4\ub97c \ucc3e\uc9c0 \ubabb\ud588\uc2b5\ub2c8\ub2e4.") }
} catch {
  Add-Type -AssemblyName System.Windows.Forms
  $answer = [System.Windows.Forms.MessageBox]::Show(
    (U "\ube60\ub978 \uc0c1\uc138 \uc870\ud68c\uc5d0 \uc2e4\ud328\ud588\uc2b5\ub2c8\ub2e4.`r`n`r`n$($_.Exception.Message)`r`n`r`n\ub098\ub77c\uc7a5\ud130 \uc6d0\ubcf8 \ud654\uba74\uc744 \ub300\uc2e0 \uc5f4\uae4c\uc694? (\uc2dc\uac04\uc774 \uac78\ub9b4 \uc218 \uc788\uc2b5\ub2c8\ub2e4.)"),
    (U "\uc0ac\uc804\uaddc\uaca9 \uc0c1\uc138"),
    "YesNo",
    "Warning"
  )
  if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) { Open-SlowG2b }
  exit 1
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object System.Windows.Forms.Form
$form.Text = (U "\uc0ac\uc804\uaddc\uaca9 \uc0c1\uc138 - $PreSpecNo")
$form.StartPosition = "CenterScreen"
$form.Width = 760
$form.Height = 610
$form.MinimumSize = New-Object System.Drawing.Size(680, 520)
$form.Font = New-Object System.Drawing.Font("Malgun Gothic", 10)
$form.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 250)

$layout = New-Object System.Windows.Forms.TableLayoutPanel
$layout.Dock = "Fill"
$layout.Padding = New-Object System.Windows.Forms.Padding(18)
$layout.RowCount = 4
$layout.ColumnCount = 1
$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize))) | Out-Null
$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize))) | Out-Null
$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize))) | Out-Null
$form.Controls.Add($layout)

$title = New-Object System.Windows.Forms.Label
$title.Text = [string]$item.prdctClsfcNoNm
$title.AutoSize = $true
$title.MaximumSize = New-Object System.Drawing.Size(690, 0)
$title.Font = New-Object System.Drawing.Font("Malgun Gothic", 15, [System.Drawing.FontStyle]::Bold)
$title.ForeColor = [System.Drawing.Color]::FromArgb(25, 50, 85)
$title.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 14)
$layout.Controls.Add($title, 0, 0)

$details = @(
  (U "\uc0ac\uc804\uaddc\uaca9\ubc88\ud638    $PreSpecNo"),
  (U "\ucc38\uc870\ubc88\ud638        $([string]$item.refNo)"),
  (U "\ubc1c\uc8fc\uae30\uad00        $([string]$item.orderInsttNm)"),
  (U "\uc2e4\uc218\uc694\uae30\uad00      $([string]$item.rlDminsttNm)"),
  (U "\ubc30\uc815\uc608\uc0b0        $(Format-Money ([string]$item.asignBdgtAmt))"),
  (U "\uc811\uc218\uc77c\uc2dc        $([string]$item.rcptDt)"),
  (U "\uc758\uacac\ub4f1\ub85d\ub9c8\uac10    $([string]$item.opninRgstClseDt)"),
  (U "\ub2f4\ub2f9\uc790          $([string]$item.ofclNm)"),
  (U "\ub2f4\ub2f9\uc790 \uc804\ud654     $([string]$item.ofclTelNo)"),
  (U "\uc5f0\uacc4 \uc785\ucc30\uacf5\uace0   $([string]$item.bidNtceNoList)")
) -join "`r`n`r`n"

$detailBox = New-Object System.Windows.Forms.TextBox
$detailBox.Dock = "Fill"
$detailBox.Multiline = $true
$detailBox.ReadOnly = $true
$detailBox.ScrollBars = "Vertical"
$detailBox.Text = $details
$detailBox.BackColor = [System.Drawing.Color]::White
$detailBox.ForeColor = [System.Drawing.Color]::FromArgb(35, 45, 60)
$detailBox.BorderStyle = "FixedSingle"
$detailBox.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 12)
$layout.Controls.Add($detailBox, 0, 1)

$filePanel = New-Object System.Windows.Forms.FlowLayoutPanel
$filePanel.Dock = "Fill"
$filePanel.AutoSize = $true
$filePanel.WrapContents = $true
$filePanel.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
$fileCount = 0
for ($index = 1; $index -le 5; $index += 1) {
  $property = $item.PSObject.Properties["specDocFileUrl$index"]
  $fileUrl = if ($property) { [string]$property.Value } else { "" }
  if (-not $fileUrl) { continue }
  $fileCount += 1
  $button = New-Object System.Windows.Forms.Button
  $button.Text = (U "\uaddc\uaca9\uc11c \ud30c\uc77c $index \uc5f4\uae30")
  $button.AutoSize = $true
  $button.Height = 36
  $button.BackColor = [System.Drawing.Color]::FromArgb(31, 111, 214)
  $button.ForeColor = [System.Drawing.Color]::White
  $button.FlatStyle = "Flat"
  $button.Tag = $fileUrl
  $button.Add_Click({ Start-Process ([string]$this.Tag) })
  $filePanel.Controls.Add($button) | Out-Null
}
if ($fileCount -eq 0) {
  $noFile = New-Object System.Windows.Forms.Label
  $noFile.Text = (U "\ub4f1\ub85d\ub41c \uaddc\uaca9\uc11c \ud30c\uc77c\uc774 \uc5c6\uc2b5\ub2c8\ub2e4.")
  $noFile.AutoSize = $true
  $noFile.ForeColor = [System.Drawing.Color]::DimGray
  $filePanel.Controls.Add($noFile) | Out-Null
}
$layout.Controls.Add($filePanel, 0, 2)

$actionPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$actionPanel.Dock = "Fill"
$actionPanel.FlowDirection = "RightToLeft"
$actionPanel.AutoSize = $true

$closeButton = New-Object System.Windows.Forms.Button
$closeButton.Text = (U "\ub2eb\uae30")
$closeButton.Width = 100
$closeButton.Height = 36
$closeButton.Add_Click({ $form.Close() })
$actionPanel.Controls.Add($closeButton) | Out-Null

$slowButton = New-Object System.Windows.Forms.Button
$slowButton.Text = (U "\ub098\ub77c\uc7a5\ud130\uc5d0\uc11c \uc5f4\uae30(\ub290\ub9bc)")
$slowButton.Width = 190
$slowButton.Height = 36
$slowButton.Add_Click({ Open-SlowG2b })
$actionPanel.Controls.Add($slowButton) | Out-Null

$layout.Controls.Add($actionPanel, 0, 3)
$form.AcceptButton = $closeButton
[void]$form.ShowDialog()
