﻿$ErrorActionPreference = "Stop"

$appName = "g2b-bid-alert"
$installDir = "C:\g2b-bid-alert"
$sourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$versionFile = Join-Path $sourceDir "VERSION"
$newVersion = if (Test-Path -LiteralPath $versionFile) { (Get-Content -LiteralPath $versionFile -Encoding UTF8 -TotalCount 1).Trim() } else { "unknown" }

if ((Test-Path -LiteralPath $installDir) -and $env:G2B_SKIP_VERSION_PROMPT -ne "1") {
  $installedVersionFile = Join-Path $installDir "VERSION"
  $installedVersion = if (Test-Path -LiteralPath $installedVersionFile) {
    (Get-Content -LiteralPath $installedVersionFile -Encoding UTF8 -TotalCount 1).Trim()
  } else {
    "알 수 없는 버전"
  }

  Write-Host ""
  Write-Host "기존 버전 $installedVersion 이(가) 설치되어 있습니다."
  Write-Host "새 버전 $newVersion 으로 덮어씌울까요?"
  $answer = Read-Host "동의하시겠습니까? (Y/N)"
  if ($answer -notmatch '^[Yy]$') {
    Write-Host "설치를 취소했습니다."
    exit 1
  }
}

New-Item -ItemType Directory -Force -Path $installDir | Out-Null

$files = @(
  "VERSION",
  "UPDATE_HISTORY.md",
  "monitor.html",
  "guide.html",
  "update_history.html",
  "update_channel.json",
  "updater.ps1",
  "settings.html",
  "config.json",
  "README.md",
  "g2b-bid-alert.exe",
  "g2b_bid_alert.py",
  "g2b_web_crawler.ps1",
  "native_monitor.ps1",
  "open_g2b_prespec.ps1",
  "launch_native_hidden.vbs",
  "launch_monitor.ps1",
  "verify_integrity.ps1",
  "show_windows_notification.ps1",
  "test_windows_notification.bat",
  "file_integrity.json",
  "install.ps1",
  "open_monitor.bat",
  "open_native_monitor.bat",
  "open_settings.bat",
  "start_monitor.bat",
  "check_once.bat",
  "uninstall.ps1"
)

foreach ($file in $files) {
  $source = Join-Path $sourceDir $file
  if (Test-Path $source) {
    if ($file -eq "config.json" -and (Test-Path -LiteralPath (Join-Path $installDir $file))) {
      $existingConfig = Join-Path $installDir $file
      try {
        Get-Content -LiteralPath $existingConfig -Encoding UTF8 -Raw | ConvertFrom-Json | Out-Null
        continue
      } catch {
        $backup = Join-Path $installDir ("config.invalid-" + (Get-Date -Format "yyyyMMddHHmmss") + ".json")
        Move-Item -LiteralPath $existingConfig -Destination $backup -Force
      }
    }
    Copy-Item -LiteralPath $source -Destination (Join-Path $installDir $file) -Force
  }
}

$shell = New-Object -ComObject WScript.Shell

function New-AppShortcut($path, $target, $arguments, $description) {
  $shortcut = $shell.CreateShortcut($path)
  $shortcut.TargetPath = $target
  $shortcut.Arguments = $arguments
  $shortcut.WorkingDirectory = $installDir
  $shortcut.Description = $description
  $chrome = Join-Path ${env:ProgramFiles} "Google\Chrome\Application\chrome.exe"
  $edge = Join-Path ${env:ProgramFiles(x86)} "Microsoft\Edge\Application\msedge.exe"
  if (Test-Path $chrome) {
    $shortcut.IconLocation = "$chrome,0"
  } elseif (Test-Path $edge) {
    $shortcut.IconLocation = "$edge,0"
  }
  $shortcut.Save()
}

$desktop = [Environment]::GetFolderPath("Desktop")
$programs = [Environment]::GetFolderPath("Programs")
$startDir = Join-Path $programs $appName
New-Item -ItemType Directory -Force -Path $startDir | Out-Null

$oldDesktopShortcut = Join-Path $desktop "나라장터 공고 모니터.lnk"
if (Test-Path -LiteralPath $oldDesktopShortcut) {
  Remove-Item -LiteralPath $oldDesktopShortcut -Force
}

$launcherExe = Join-Path $installDir "g2b-bid-alert.exe"
$launcherScript = Join-Path $installDir "native_monitor.ps1"
$hiddenLauncher = Join-Path $installDir "launch_native_hidden.vbs"
$powershell = Join-Path $env:SystemRoot "System32\WindowsPowerShell\v1.0\powershell.exe"
$wscript = Join-Path $env:SystemRoot "System32\wscript.exe"
$uninstall = Join-Path $installDir "uninstall.ps1"

$shortcutTarget = $wscript
$shortcutArguments = "`"$hiddenLauncher`""

New-AppShortcut `
  -path (Join-Path $desktop "$appName.lnk") `
  -target $shortcutTarget `
  -arguments $shortcutArguments `
  -description "g2b-bid-alert 실행"

New-AppShortcut `
  -path (Join-Path $startDir "$appName.lnk") `
  -target $shortcutTarget `
  -arguments $shortcutArguments `
  -description "g2b-bid-alert 실행"

New-AppShortcut `
  -path (Join-Path $startDir "제거.lnk") `
  -target $powershell `
  -arguments "-NoProfile -ExecutionPolicy Bypass -File `"$uninstall`"" `
  -description "나라장터 공고 모니터 제거"

Write-Host ""
Write-Host "설치가 완료되었습니다."
Write-Host "바탕화면의 '$appName' 바로가기로 실행하세요."
Write-Host ""

if ($env:G2B_SKIP_AUTO_LAUNCH -ne "1") {
  try {
    Start-Process -FilePath $shortcutTarget -ArgumentList $shortcutArguments -ErrorAction Stop
  } catch {
    Write-Host ""
    Write-Host "설치는 완료되었지만 자동 실행은 차단되었습니다."
    Write-Host "바탕화면 바로가기로 실행하세요."
  }
}
