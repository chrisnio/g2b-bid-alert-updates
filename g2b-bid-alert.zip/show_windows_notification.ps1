param(
  [string]$Title = "G2B Bid Alert",
  [string]$Message = "",
  [string]$Url = ""
)

$ErrorActionPreference = "Stop"

function Limit-Text([string]$Text, [int]$MaxLength) {
  if (-not $Text) { return "" }
  if ($Text.Length -le $MaxLength) { return $Text }
  return $Text.Substring(0, [Math]::Max(0, $MaxLength - 3)) + "..."
}

function Escape-Xml([string]$Text) {
  return [Security.SecurityElement]::Escape($Text)
}

function Show-BalloonNotification {
  param(
    [string]$BalloonTitle,
    [string]$BalloonMessage,
    [string]$LaunchUrl
  )

  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing

  $notify = New-Object System.Windows.Forms.NotifyIcon
  $notify.Icon = [System.Drawing.SystemIcons]::Information
  $notify.Visible = $true
  $notify.Text = "G2B Bid Alert"

  if ($LaunchUrl) {
    $notify.add_BalloonTipClicked({
      Start-Process $LaunchUrl
    })
  }

  $notify.ShowBalloonTip(
    12000,
    (Limit-Text $BalloonTitle 63),
    (Limit-Text $BalloonMessage 240),
    [System.Windows.Forms.ToolTipIcon]::Info
  )
  Start-Sleep -Seconds 13
  $notify.Dispose()
}

function Show-ToastNotification {
  param(
    [string]$ToastTitle,
    [string]$ToastMessage,
    [string]$LaunchUrl
  )

  Add-Type -AssemblyName System.Runtime.WindowsRuntime
  [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
  [Windows.UI.Notifications.ToastNotification, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
  [Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null

  $safeTitle = Escape-Xml (Limit-Text $ToastTitle 80)
  $safeMessage = Escape-Xml (Limit-Text $ToastMessage 300)
  $safeLaunch = Escape-Xml $LaunchUrl

  $xmlText = @"
<toast activationType="protocol" launch="$safeLaunch">
  <visual>
    <binding template="ToastGeneric">
      <text>$safeTitle</text>
      <text>$safeMessage</text>
    </binding>
  </visual>
</toast>
"@

  $xml = New-Object Windows.Data.Xml.Dom.XmlDocument
  $xml.LoadXml($xmlText)

  $toast = [Windows.UI.Notifications.ToastNotification]::new($xml)
  $notifier = [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("PowerShell")
  $notifier.Show($toast)
  Start-Sleep -Seconds 2
}

try {
  Show-ToastNotification -ToastTitle $Title -ToastMessage $Message -LaunchUrl $Url
} catch {
  try {
    Show-BalloonNotification -BalloonTitle $Title -BalloonMessage $Message -LaunchUrl $Url
  } catch {
    exit 1
  }
}
