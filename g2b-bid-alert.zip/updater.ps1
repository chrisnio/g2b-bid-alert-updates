param(
  [Parameter(Mandatory = $true)][string]$ManifestUrl,
  [Parameter(Mandatory = $true)][string]$AppDir,
  [int]$CurrentPid = 0,
  [switch]$NoRestart
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

function Read-RemoteJson([string]$Location) {
  if (Test-Path -LiteralPath $Location) {
    return Get-Content -LiteralPath $Location -Encoding UTF8 -Raw | ConvertFrom-Json
  }
  $response = Invoke-RestMethod -Uri $Location -TimeoutSec 30 -Headers @{ "User-Agent" = "g2b-bid-alert-updater/1.0" }
  if ($response -is [string]) {
    return $response.TrimStart([char]0xFEFF) | ConvertFrom-Json
  }
  return $response
}

function Resolve-DownloadLocation([string]$ManifestLocation, [string]$Value) {
  if ([Uri]::IsWellFormedUriString($Value, [UriKind]::Absolute)) { return $Value }
  if (Test-Path -LiteralPath $ManifestLocation) {
    return Join-Path (Split-Path -Parent (Resolve-Path -LiteralPath $ManifestLocation)) $Value
  }
  return ([Uri]::new([Uri]$ManifestLocation, $Value)).AbsoluteUri
}

function Get-UpdateFile([string]$Location, [string]$Destination) {
  if (Test-Path -LiteralPath $Location) {
    Copy-Item -LiteralPath $Location -Destination $Destination -Force
  } else {
    Invoke-WebRequest -Uri $Location -OutFile $Destination -TimeoutSec 120 -Headers @{ "User-Agent" = "g2b-bid-alert-updater/1.0" }
  }
}

function Show-UpdateError([string]$Message) {
  try {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show($Message, "g2b-bid-alert 업데이트 오류", "OK", "Error") | Out-Null
  } catch {}
}

$tempDir = Join-Path $env:TEMP ("g2b-update-" + [guid]::NewGuid().ToString("N"))
$logPath = Join-Path $env:TEMP "g2b-bid-alert-update.log"

try {
  New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
  "Started: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" | Set-Content -LiteralPath $logPath -Encoding UTF8

  $manifest = Read-RemoteJson $ManifestUrl
  if (-not $manifest.version -or -not $manifest.package_url -or -not $manifest.sha256) {
    throw "업데이트 정보에 version, package_url 또는 sha256이 없습니다."
  }

  $packageLocation = Resolve-DownloadLocation $ManifestUrl ([string]$manifest.package_url)
  $packagePath = Join-Path $tempDir "update-package.zip"
  Get-UpdateFile $packageLocation $packagePath

  $actualHash = (Get-FileHash -LiteralPath $packagePath -Algorithm SHA256).Hash.ToLowerInvariant()
  $expectedHash = ([string]$manifest.sha256).Trim().ToLowerInvariant()
  if ($actualHash -ne $expectedHash) {
    throw "업데이트 파일 무결성 검증에 실패했습니다."
  }

  $payloadDir = Join-Path $tempDir "payload"
  Expand-Archive -LiteralPath $packagePath -DestinationPath $payloadDir -Force
  $installScript = Join-Path $payloadDir "install.ps1"
  if (-not (Test-Path -LiteralPath $installScript)) { throw "업데이트 패키지에 install.ps1이 없습니다." }

  if ($CurrentPid -gt 0) {
    try {
      $running = Get-Process -Id $CurrentPid -ErrorAction Stop
      if (-not $running.WaitForExit(30000)) {
        Start-Process -FilePath "taskkill.exe" -WindowStyle Hidden -Wait -ArgumentList @("/PID", [string]$CurrentPid, "/T", "/F") | Out-Null
      }
    } catch {}
  }

  $env:G2B_SKIP_VERSION_PROMPT = "1"
  if ($NoRestart) { $env:G2B_SKIP_AUTO_LAUNCH = "1" }
  & $installScript *>> $logPath
  if ($LASTEXITCODE) { throw "설치 프로그램이 종료 코드 $LASTEXITCODE 을 반환했습니다." }
} catch {
  $_.Exception.ToString() | Add-Content -LiteralPath $logPath -Encoding UTF8
  Show-UpdateError "자동 업데이트에 실패했습니다.`n`n$($_.Exception.Message)`n`n로그: $logPath"
  exit 1
} finally {
  Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue
}

try {
  $selfPath = $MyInvocation.MyCommand.Path
  if ($selfPath -and (Split-Path -Parent $selfPath) -eq $env:TEMP) {
    Remove-Item -LiteralPath $selfPath -Force -ErrorAction SilentlyContinue
  }
} catch {}

exit 0
