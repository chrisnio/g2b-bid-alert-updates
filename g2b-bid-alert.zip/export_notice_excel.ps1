param(
  [Parameter(Mandatory = $true)][string]$InputJson,
  [Parameter(Mandatory = $true)][string]$OutputPath
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

function U([string]$Text) {
  [Text.RegularExpressions.Regex]::Replace($Text, "\\u([0-9a-fA-F]{4})", {
    param($m)
    [char][Convert]::ToInt32($m.Groups[1].Value, 16)
  })
}

function XmlEscape([string]$Value) {
  if ($null -eq $Value) { return "" }
  return [Security.SecurityElement]::Escape($Value)
}

function ColumnName([int]$Number) {
  $name = ""
  while ($Number -gt 0) {
    $Number -= 1
    $name = [char](65 + ($Number % 26)) + $name
    $Number = [Math]::Floor($Number / 26)
  }
  return $name
}

function InlineCell([string]$Reference, [string]$Value, [int]$Style = 0) {
  $safe = XmlEscape $Value
  return "<c r=`"$Reference`" t=`"inlineStr`" s=`"$Style`"><is><t xml:space=`"preserve`">$safe</t></is></c>"
}

function NumberCell([string]$Reference, $Value, [int]$Style = 2) {
  $number = 0L
  if ($null -eq $Value -or -not [long]::TryParse(([string]$Value -replace "\D", ""), [ref]$number)) {
    return InlineCell $Reference "" 0
  }
  return "<c r=`"$Reference`" s=`"$Style`"><v>$number</v></c>"
}

function AddZipText($Zip, [string]$Path, [string]$Text) {
  $entry = $Zip.CreateEntry($Path, [IO.Compression.CompressionLevel]::Optimal)
  $stream = $entry.Open()
  $writer = New-Object IO.StreamWriter($stream, (New-Object Text.UTF8Encoding($false)))
  try { $writer.Write($Text) } finally { $writer.Dispose(); $stream.Dispose() }
}

$parsedRows = Get-Content -LiteralPath $InputJson -Encoding UTF8 -Raw | ConvertFrom-Json
$rows = if ($parsedRows -is [System.Array]) { $parsedRows } else { @($parsedRows) }
$headers = @(
  (U "\uAD00\uC2EC"), (U "\uC0C1\uD0DC"), (U "\uACF5\uACE0\uBA85"), (U "\uAD6C\uBD84"),
  (U "\uACF5\uACE0\uAE30\uAD00"), (U "\uC218\uC694\uAE30\uAD00"), (U "\uBC30\uC815\uC608\uC0B0"),
  (U "\uCD94\uC815\uAC00\uACA9"), (U "\uAC8C\uC2DC\uC77C"), (U "\uB9C8\uAC10\uC77C"),
  (U "\uAC80\uC0C9 \uD0A4\uC6CC\uB4DC"), (U "\uC0C1\uC138 \uB9C1\uD06C"), (U "\uACF5\uACE0 ID")
)

$sheetRows = New-Object Text.StringBuilder
$headerCells = New-Object Text.StringBuilder
for ($column = 1; $column -le $headers.Count; $column += 1) {
  [void]$headerCells.Append((InlineCell "$(ColumnName $column)1" $headers[$column - 1] 1))
}
[void]$sheetRows.Append("<row r=`"1`" ht=`"24`" customHeight=`"1`">$headerCells</row>")

$hyperlinks = New-Object Text.StringBuilder
$relationships = New-Object Text.StringBuilder
$relationshipIndex = 1
$rowNumber = 2
foreach ($item in $rows) {
  $style = if ([bool]$item.starred) { 3 } else { 0 }
  $cells = New-Object Text.StringBuilder
  [void]$cells.Append((InlineCell "A$rowNumber" $(if ([bool]$item.starred) { U "\u2605" } else { "" }) $style))
  [void]$cells.Append((InlineCell "B$rowNumber" ([string]$item.status) $style))
  [void]$cells.Append((InlineCell "C$rowNumber" ([string]$item.title) $style))
  [void]$cells.Append((InlineCell "D$rowNumber" ([string]$item.type) $style))
  [void]$cells.Append((InlineCell "E$rowNumber" ([string]$item.noticeAgency) $style))
  [void]$cells.Append((InlineCell "F$rowNumber" ([string]$item.demandAgency) $style))
  [void]$cells.Append((NumberCell "G$rowNumber" $item.budget $(if ([bool]$item.starred) { 4 } else { 2 })))
  [void]$cells.Append((NumberCell "H$rowNumber" $item.estimatedPrice $(if ([bool]$item.starred) { 4 } else { 2 })))
  [void]$cells.Append((InlineCell "I$rowNumber" ([string]$item.posted) $style))
  [void]$cells.Append((InlineCell "J$rowNumber" ([string]$item.close) $style))
  [void]$cells.Append((InlineCell "K$rowNumber" ([string]$item.keyword) $style))
  [void]$cells.Append((InlineCell "L$rowNumber" $(if ($item.url) { U "\uC0C1\uC138 \uBCF4\uAE30" } else { "" }) 5))
  [void]$cells.Append((InlineCell "M$rowNumber" ([string]$item.id) $style))
  [void]$sheetRows.Append("<row r=`"$rowNumber`" ht=`"21`" customHeight=`"1`">$cells</row>")

  if ($item.url -and ([string]$item.url -match "^https?://")) {
    $rid = "rId$relationshipIndex"
    [void]$hyperlinks.Append("<hyperlink ref=`"L$rowNumber`" r:id=`"$rid`"/>")
    [void]$relationships.Append("<Relationship Id=`"$rid`" Type=`"http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink`" Target=`"$(XmlEscape ([string]$item.url))`" TargetMode=`"External`"/>")
    $relationshipIndex += 1
  }
  $rowNumber += 1
}

$lastRow = [Math]::Max(1, $rowNumber - 1)
$sheetXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>
  <cols>
    <col min="1" max="1" width="7" customWidth="1"/><col min="2" max="2" width="16" customWidth="1"/>
    <col min="3" max="3" width="52" customWidth="1"/><col min="4" max="4" width="14" customWidth="1"/>
    <col min="5" max="6" width="25" customWidth="1"/><col min="7" max="8" width="17" customWidth="1"/>
    <col min="9" max="10" width="14" customWidth="1"/><col min="11" max="11" width="20" customWidth="1"/>
    <col min="12" max="12" width="13" customWidth="1"/><col min="13" max="13" width="23" customWidth="1"/>
  </cols>
  <sheetData>$sheetRows</sheetData>
  <autoFilter ref="A1:M$lastRow"/>
  $(if ($hyperlinks.Length -gt 0) { "<hyperlinks>$hyperlinks</hyperlinks>" } else { "" })
</worksheet>
"@

$stylesXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="4">
    <font><sz val="10"/><name val="Malgun Gothic"/></font>
    <font><b/><color rgb="FFFFFFFF"/><sz val="10"/><name val="Malgun Gothic"/></font>
    <font><color rgb="FFF59E0B"/><sz val="10"/><name val="Malgun Gothic"/></font>
    <font><u/><color rgb="FF0563C1"/><sz val="10"/><name val="Malgun Gothic"/></font>
  </fonts>
  <fills count="4">
    <fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF1F4E78"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFFFF7D6"/><bgColor indexed="64"/></patternFill></fill>
  </fills>
  <borders count="2">
    <border><left/><right/><top/><bottom/><diagonal/></border>
    <border><left style="thin"><color rgb="FFD9E2F3"/></left><right style="thin"><color rgb="FFD9E2F3"/></right><top style="thin"><color rgb="FFD9E2F3"/></top><bottom style="thin"><color rgb="FFD9E2F3"/></bottom><diagonal/></border>
  </borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="6">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment vertical="center"/></xf>
    <xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="3" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
    <xf numFmtId="0" fontId="2" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center"/></xf>
    <xf numFmtId="3" fontId="2" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
    <xf numFmtId="0" fontId="3" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
  </cellXfs>
  <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>
"@

$contentTypes = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>
"@

$rootRels = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>
"@

$workbookXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets><sheet name="$(U '\uAC80\uC0C9 \uACF5\uACE0')" sheetId="1" r:id="rId1"/></sheets>
</workbook>
"@

$workbookRels = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>
"@

$sheetRels = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">$relationships</Relationships>
"@

$now = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
$coreXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <dc:title>$(U '\uB098\uB77C\uC7A5\uD130 \uAC80\uC0C9 \uACF5\uACE0')</dc:title><dc:creator>$(U '\uB098\uB77C\uC7A5\uD130 \uACF5\uACE0 \uBAA8\uB2C8\uD130')</dc:creator>
  <dcterms:created xsi:type="dcterms:W3CDTF">$now</dcterms:created>
</cp:coreProperties>
"@
$appXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>$(U '\uB098\uB77C\uC7A5\uD130 \uACF5\uACE0 \uBAA8\uB2C8\uD130')</Application></Properties>
"@

$parent = Split-Path -Parent $OutputPath
if ($parent -and -not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
if (Test-Path -LiteralPath $OutputPath) { Remove-Item -LiteralPath $OutputPath -Force }

$file = [IO.File]::Open($OutputPath, [IO.FileMode]::CreateNew)
$zip = New-Object IO.Compression.ZipArchive($file, [IO.Compression.ZipArchiveMode]::Create)
try {
  AddZipText $zip "[Content_Types].xml" $contentTypes
  AddZipText $zip "_rels/.rels" $rootRels
  AddZipText $zip "docProps/core.xml" $coreXml
  AddZipText $zip "docProps/app.xml" $appXml
  AddZipText $zip "xl/workbook.xml" $workbookXml
  AddZipText $zip "xl/_rels/workbook.xml.rels" $workbookRels
  AddZipText $zip "xl/styles.xml" $stylesXml
  AddZipText $zip "xl/worksheets/sheet1.xml" $sheetXml
  if ($relationships.Length -gt 0) { AddZipText $zip "xl/worksheets/_rels/sheet1.xml.rels" $sheetRels }
} finally {
  $zip.Dispose()
  $file.Dispose()
}

Write-Output $OutputPath
