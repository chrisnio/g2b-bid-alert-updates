﻿$ErrorActionPreference = "Stop"

$appDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$verify = Join-Path $appDir "verify_integrity.ps1"
$monitor = Join-Path $appDir "monitor.html"

try {
  & $verify
  if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
  }
  Start-Process -FilePath $monitor
} catch {
  if ($_.Exception.Message -notmatch "프로그램 파일이 배포 당시와 다릅니다") {
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show($_.Exception.Message, "나라장터 공고 모니터 실행 오류", "OK", "Error") | Out-Null
  }
  exit 1
}
