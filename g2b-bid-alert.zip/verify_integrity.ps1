﻿$ErrorActionPreference = "Stop"

$appDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$manifestPath = Join-Path $appDir "file_integrity.json"

if (-not (Test-Path -LiteralPath $manifestPath)) {
  throw "무결성 기준 파일(file_integrity.json)을 찾을 수 없습니다."
}

$manifest = Get-Content -LiteralPath $manifestPath -Encoding UTF8 | ConvertFrom-Json
$problems = New-Object System.Collections.Generic.List[string]

foreach ($entry in $manifest.files) {
  $path = Join-Path $appDir $entry.path
  if (-not (Test-Path -LiteralPath $path)) {
    $problems.Add("누락: $($entry.path)")
    continue
  }

  $actual = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
  $expected = [string]$entry.sha256
  if ($actual -ne $expected.ToLowerInvariant()) {
    $problems.Add("변조 의심: $($entry.path)")
  }
}

if ($problems.Count -gt 0) {
  $message = "프로그램 파일이 배포 당시와 다릅니다.`n`n" +
    ($problems -join "`n") +
    "`n`n공식 배포본으로 다시 설치하세요."
  Add-Type -AssemblyName PresentationFramework
  [System.Windows.MessageBox]::Show($message, "나라장터 공고 모니터 - 무결성 오류", "OK", "Error") | Out-Null
  throw $message
}

exit 0
