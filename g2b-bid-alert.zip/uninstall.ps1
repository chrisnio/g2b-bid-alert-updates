﻿$ErrorActionPreference = "SilentlyContinue"

$appName = "나라장터 공고 모니터"
$installDir = "C:\g2b-bid-alert"
$desktopShortcut = Join-Path ([Environment]::GetFolderPath("Desktop")) "$appName.lnk"
$startDir = Join-Path ([Environment]::GetFolderPath("Programs")) $appName

Remove-Item -LiteralPath $desktopShortcut -Force
Remove-Item -LiteralPath $startDir -Recurse -Force

Write-Host "바로가기를 제거했습니다."
Write-Host "설치 폴더를 삭제합니다: $installDir"

$cmd = "/c timeout /t 1 > nul & rmdir /s /q `"$installDir`""
Start-Process -FilePath "cmd.exe" -ArgumentList $cmd -WindowStyle Hidden
