using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

public static class G2BBidAlertLauncher
{
    [STAThread]
    public static int Main(string[] args)
    {
        if (args.Length > 0 && string.Equals(args[0], "--probe", StringComparison.OrdinalIgnoreCase))
        {
            return 0;
        }

        string appDir = AppDomain.CurrentDomain.BaseDirectory;
        string launcherScript = Path.Combine(appDir, "launch_monitor.ps1");

        if (!File.Exists(launcherScript))
        {
            MessageBox.Show(
                "launch_monitor.ps1 was not found. Please reinstall G2B Bid Alert.",
                "G2B Bid Alert",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error
            );
            return 1;
        }

        string powershell = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.Windows),
            "System32",
            "WindowsPowerShell",
            "v1.0",
            "powershell.exe"
        );

        var startInfo = new ProcessStartInfo
        {
            FileName = powershell,
            Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"" + launcherScript + "\"",
            WorkingDirectory = appDir,
            UseShellExecute = false,
            CreateNoWindow = true
        };

        try
        {
            Process.Start(startInfo);
            return 0;
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                ex.Message,
                "G2B Bid Alert",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error
            );
            return 1;
        }
    }
}
