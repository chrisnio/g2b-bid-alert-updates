@echo off
cd /d "%~dp0"
python g2b_bid_alert.py
pause
