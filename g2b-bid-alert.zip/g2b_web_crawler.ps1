param(
  [Parameter(Mandatory=$true)][string]$ConfigPath
)

$ErrorActionPreference = "Stop"
$script:StatsPath = Join-Path (Split-Path -Parent $ConfigPath) "crawler_status.json"

function U([string]$Text) {
  [Text.RegularExpressions.Regex]::Replace($Text, "\\u([0-9a-fA-F]{4})", {
    param($m)
    [char][Convert]::ToInt32($m.Groups[1].Value, 16)
  })
}

function Find-Chrome {
  $paths = @(
    (Join-Path $env:ProgramFiles "Google\Chrome\Application\chrome.exe"),
    (Join-Path ${env:ProgramFiles(x86)} "Google\Chrome\Application\chrome.exe"),
    (Join-Path $env:ProgramFiles "Microsoft\Edge\Application\msedge.exe"),
    (Join-Path ${env:ProgramFiles(x86)} "Microsoft\Edge\Application\msedge.exe")
  )
  foreach ($path in $paths) {
    if (Test-Path -LiteralPath $path) { return $path }
  }
  throw "Chrome or Edge was not found."
}

function Send-Cdp($WebSocketUrl, [int]$Id, [string]$Method, $Params) {
  $client = [System.Net.WebSockets.ClientWebSocket]::new()
  $client.ConnectAsync([Uri]$WebSocketUrl, [Threading.CancellationToken]::None).Wait(5000) | Out-Null
  try {
    $payload = (@{ id = $Id; method = $Method; params = $Params } | ConvertTo-Json -Depth 20 -Compress)
    $bytes = [Text.Encoding]::UTF8.GetBytes($payload)
    $client.SendAsync([ArraySegment[byte]]::new($bytes), [System.Net.WebSockets.WebSocketMessageType]::Text, $true, [Threading.CancellationToken]::None).Wait(5000) | Out-Null

    $buffer = New-Object byte[] 4194304
    $deadline = (Get-Date).AddSeconds(75)
    while ((Get-Date) -lt $deadline) {
      $text = ""
      do {
        $receiveTask = $client.ReceiveAsync([ArraySegment[byte]]::new($buffer), [Threading.CancellationToken]::None)
        if (-not $receiveTask.Wait(30000)) { throw "CDP_TIMEOUT" }
        $result = $receiveTask.Result
        $text += [Text.Encoding]::UTF8.GetString($buffer, 0, $result.Count)
      } while (-not $result.EndOfMessage)
      if (-not $text) { continue }
      $message = $text | ConvertFrom-Json
      if ($message.id -eq $Id) { return $message }
    }
    throw "CDP_TIMEOUT"
  } finally {
    $client.Dispose()
  }
}

$config = Get-Content -LiteralPath $ConfigPath -Encoding UTF8 -Raw | ConvertFrom-Json
$keywords = @($config.keywords | ForEach-Object { ([string]$_).Trim() } | Where-Object { $_ })

function Clean-WebTitle([string]$Title) {
  $clean = $Title.Trim()
  $prefixPattern = "^(" + (U "\uC81C\uD55C") + "|" + (U "\uC77C\uBC18") + "|" + (U "\uC9C0\uBA85") + "|" + (U "\uC218\uC758") + ")(?=\S)"
  $clean = $clean -replace $prefixPattern, ""
  return $clean.Trim()
}

function Clean-WebAmount([string]$Amount) {
  $clean = $Amount.Trim()
  if (-not $clean) { return "" }
  if ($clean -match "^[0-9,]+$") { return $clean.Replace(",", "") }
  if ($clean -match "([0-9][0-9,]+)") { return $matches[1].Replace(",", "") }
  return ""
}

function Web-DetailUrl([string]$BidNo) {
  if (-not $BidNo) { return "https://www.g2b.go.kr/" }
  return "https://www.g2b.go.kr:8101/ep/tbid/tbidFwd.do?bidno=$([Uri]::EscapeDataString($BidNo))"
}

$chrome = Find-Chrome
$port = Get-Random -Minimum 9300 -Maximum 9700
$profile = Join-Path $env:TEMP ("g2b-crawler-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Force -Path $profile | Out-Null

$process = $null
$tab = $null
try {
  $process = Start-Process -FilePath $chrome -ArgumentList @(
    "--headless",
    "--disable-gpu",
    "--no-first-run",
    "--disable-extensions",
    "--user-data-dir=$profile",
    "--remote-debugging-port=$port",
    "about:blank"
  ) -PassThru -WindowStyle Hidden

  Start-Sleep -Seconds 2
  $tab = Invoke-RestMethod -Uri "http://127.0.0.1:$port/json/new?https://www.g2b.go.kr/" -Method Put -TimeoutSec 5
  Start-Sleep -Seconds 8

  $allRows = @()
  $evalId = 1
  $keywordIndex = 0
  foreach ($keyword in $keywords) {
    if ($keywordIndex -gt 0) {
      [void](Send-Cdp $tab.webSocketDebuggerUrl $evalId "Page.navigate" @{ url = "https://www.g2b.go.kr/" })
      $evalId += 1
      Start-Sleep -Seconds 8
    }
    $keywordJson = [string]$keyword | ConvertTo-Json -Compress
    $script = @(
      "(async () => {",
      "  const keyword = $keywordJson;",
      "  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));",
      "  const inputId = 'mf_wfm_container_wq_uuid_929_wq_uuid_938_searchKeyword';",
      "  const searchButtonId = 'mf_wfm_container_wq_uuid_929_wq_uuid_938_btnUntyDtlSrch';",
      "  function getSearchControls() {",
      "    return {",
      "      input: document.getElementById(inputId) || document.querySelector('input[id*=""searchKeyword""]'),",
      "      searchButton: document.getElementById(searchButtonId) || document.querySelector('[id*=""btnUntyDtlSrch""]')",
      "    };",
      "  }",
      "  function setValue(el, value) {",
      "    const comp = window[el.id] || (window.`$p && window.`$p.getComponentById ? window.`$p.getComponentById(el.id) : null);",
      "    if (comp && typeof comp.setValue === 'function') comp.setValue(value);",
      "    el.focus(); el.click();",
      "    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;",
      "    setter.call(el, value);",
      "    el.setAttribute('value', value);",
      "    for (const t of ['keydown','keypress','keyup','input','change','blur']) el.dispatchEvent(new Event(t, { bubbles: true }));",
      "  }",
      "  function parseRows(keyword) {",
      "    const text = document.body.innerText || '';",
      "    const part = text.split('\uD1B5\uD569\uC0C1\uC138 \uBAA9\uB85D')[1] || '';",
      "    const chunks = part.split(/\n(?=\d+\t\uC785\uCC30\uACF5\uACE0)/).slice(1, 101);",
      "    return chunks.map(row => {",
      "      const cols = row.replace(/\n+/g, '\t').split(/\t+/).map(v => v.trim()).filter(Boolean);",
      "      return {",
      "        keyword: keyword,",
      "        no: cols[0] || '',",
      "        stage: cols[1] || '',",
      "        workType: cols[2] || '',",
      "        title: cols[3] || '',",
      "        bidNo: cols[5] || '',",
      "        businessDate: cols[6] || '',",
      "        noticeAgency: cols[7] || '',",
      "        demandAgency: cols[8] || '',",
      "        noticeDate: cols[9] || '',",
      "        contractType: cols[10] || '',",
      "        method: cols[11] || '',",
      "        amount: cols[12] || '',",
      "        refNo: cols[13] || ''",
      "      };",
      "    }).filter(row => row.stage === '\uC785\uCC30\uACF5\uACE0' && row.bidNo);",
      "  }",
      "  function setHundredRows() {",
      "    const targets = Array.from(document.querySelectorAll('a, button, input')).filter(e => ((e.innerText || e.value || '').trim() === '100'));",
      "    if (targets.length) targets[0].click();",
      "  }",
      "  const { input, searchButton } = getSearchControls();",
      "  if (!input) return JSON.stringify({ error: 'SEARCH_INPUT_NOT_FOUND', rows: [] });",
      "  if (!searchButton) return JSON.stringify({ error: 'SEARCH_BUTTON_NOT_FOUND', rows: [] });",
      "  setValue(input, keyword);",
      "  searchButton.click();",
      "  await sleep(9000);",
      "  setHundredRows();",
      "  await sleep(3000);",
      "  return JSON.stringify({ error: '', rows: parseRows(keyword) });",
      "})()"
    ) -join "`n"

    $response = Send-Cdp $tab.webSocketDebuggerUrl $evalId "Runtime.evaluate" @{
      expression = $script
      awaitPromise = $true
      returnByValue = $true
    }
    $evalId += 1
    if (-not $response.result.result.value) {
      if ($response.result.exceptionDetails) { throw ($response.result.exceptionDetails.text) }
      throw "CRAWLER_EMPTY_RESULT"
    }
    $parsedKeyword = $response.result.result.value | ConvertFrom-Json
    if ($parsedKeyword.error) { throw $parsedKeyword.error }
    $allRows += @($parsedKeyword.rows)
    $keywordIndex += 1
  }

  $parsed = [pscustomobject]@{ rows = @($allRows) }

  $noticeMap = @{}
  $serviceRows = 0
  foreach ($row in @($parsed.rows)) {
    if ([string]$row.workType -ne (U "\uC6A9\uC5ED")) { continue }
    $serviceRows += 1
    $title = Clean-WebTitle ([string]$row.title)
    $matchedKeywords = @()
    foreach ($keyword in $keywords) {
      if ($title.IndexOf($keyword, [StringComparison]::CurrentCultureIgnoreCase) -ge 0) { $matchedKeywords += $keyword }
    }
    $matchedKeywords = @($matchedKeywords | Select-Object -Unique)
    if ($matchedKeywords.Count -eq 0) { continue }
    $bidNo = [string]$row.bidNo
    if (-not $bidNo) { continue }
    $noticeDate = [string]$row.noticeDate
    if ($noticeDate -match "^\d{4}/\d{2}/\d{2}$") { $noticeDate = $noticeDate.Replace("/", "-") + " 00:00" }
    $id = $bidNo + "-WEB"
    if ($noticeMap.ContainsKey($id)) {
      $existing = $noticeMap[$id]
      $merged = @(([string]$existing.keyword -split ",\s*") + $matchedKeywords | Where-Object { $_ } | Select-Object -Unique)
      $existing.keyword = ($merged -join ", ")
      continue
    }
    $noticeMap[$id] = [pscustomobject]@{
      keyword = ($matchedKeywords -join ", ")
      id = $id
      title = $title
      serviceType = U "\uC6A9\uC5ED(\uC6F9)"
      noticeKind = U "\uC6F9 \uAC80\uC0C9"
      noticeAgency = [string]$row.noticeAgency
      demandAgency = [string]$row.demandAgency
      noticeDate = $noticeDate
      closeDate = "-"
      budget = Clean-WebAmount ([string]$row.amount)
      estimatedPrice = ""
      detailUrl = Web-DetailUrl $bidNo
    }
  }
  $notices = @($noticeMap.Values)

  [pscustomobject]@{
    checked_at = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    source = "crawler"
    scanned_rows = @($parsed.rows).Count
    service_rows = $serviceRows
    matched_rows = @($notices).Count
  } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $script:StatsPath -Encoding UTF8

  $notices | ConvertTo-Json -Depth 8
} finally {
  try {
    if ($tab) { Invoke-WebRequest -Uri "http://127.0.0.1:$port/json/close/$($tab.id)" -UseBasicParsing -TimeoutSec 3 | Out-Null }
  } catch {}
  try {
    if ($process -and -not $process.HasExited) {
      Start-Process -FilePath "taskkill.exe" -WindowStyle Hidden -Wait -ArgumentList @("/PID", [string]$process.Id, "/T", "/F") | Out-Null
    }
  } catch {}
  Remove-Item -LiteralPath $profile -Recurse -Force -ErrorAction SilentlyContinue
}
