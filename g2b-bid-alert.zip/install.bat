@echo off
setlocal
chcp 65001 > nul
cd /d "%~dp0"
echo.
echo 나라장터 공고 모니터를 설치합니다.
echo 설치 위치: C:\g2b-bid-alert
echo 설치 후 바탕화면에 "나라장터 공고 모니터" 바로가기가 생성됩니다.
echo.
set /p ANSWER=동의하시겠습니까? (Y/N): 
if /I not "%ANSWER%"=="Y" (
  echo 설치를 취소했습니다.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
pause
