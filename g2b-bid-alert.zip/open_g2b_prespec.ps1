param(
  [Parameter(Mandatory = $true)][string]$PreSpecNo
)

$ErrorActionPreference = "Stop"

function Find-Browser {
  $paths = @(
    (Join-Path $env:ProgramFiles "Google\Chrome\Application\chrome.exe"),
    (Join-Path ${env:ProgramFiles(x86)} "Google\Chrome\Application\chrome.exe"),
    (Join-Path $env:ProgramFiles "Microsoft\Edge\Application\msedge.exe"),
    (Join-Path ${env:ProgramFiles(x86)} "Microsoft\Edge\Application\msedge.exe")
  )
  foreach ($path in $paths) {
    if (Test-Path -LiteralPath $path) { return $path }
  }
  throw "Chrome or Edge was not found."
}

function Send-Cdp($WebSocketUrl, [int]$Id, [string]$Method, $Params) {
  $client = [System.Net.WebSockets.ClientWebSocket]::new()
  $client.ConnectAsync([Uri]$WebSocketUrl, [Threading.CancellationToken]::None).Wait(5000) | Out-Null
  try {
    $payload = (@{ id = $Id; method = $Method; params = $Params } | ConvertTo-Json -Depth 20 -Compress)
    $bytes = [Text.Encoding]::UTF8.GetBytes($payload)
    $client.SendAsync([ArraySegment[byte]]::new($bytes), [System.Net.WebSockets.WebSocketMessageType]::Text, $true, [Threading.CancellationToken]::None).Wait(5000) | Out-Null
    $buffer = New-Object byte[] 4194304
    while ($true) {
      $text = ""
      do {
        $result = $client.ReceiveAsync([ArraySegment[byte]]::new($buffer), [Threading.CancellationToken]::None).Result
        $text += [Text.Encoding]::UTF8.GetString($buffer, 0, $result.Count)
      } while (-not $result.EndOfMessage)
      $message = $text | ConvertFrom-Json
      if ($message.id -eq $Id) { return $message }
    }
  } finally {
    $client.Dispose()
  }
}

$browser = Find-Browser
$port = Get-Random -Minimum 9701 -Maximum 9999
$profile = Join-Path $env:TEMP ("g2b-prespec-view-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Force -Path $profile | Out-Null

$process = Start-Process -FilePath $browser -ArgumentList @(
  "--new-window",
  "--no-first-run",
  "--disable-extensions",
  "--user-data-dir=$profile",
  "--remote-debugging-port=$port",
  "https://www.g2b.go.kr/"
) -PassThru

$tab = $null
for ($attempt = 0; $attempt -lt 30 -and -not $tab; $attempt += 1) {
  Start-Sleep -Milliseconds 500
  try {
    $tabs = Invoke-RestMethod -Uri "http://127.0.0.1:$port/json" -TimeoutSec 3
    $tab = @($tabs | Where-Object { $_.type -eq "page" -and $_.url -like "https://www.g2b.go.kr/*" })[0]
  } catch {}
}
if (-not $tab) { throw "Could not connect to the browser." }

$numberJson = $PreSpecNo | ConvertTo-Json -Compress
$script = @"
(async () => {
  if (!window.com || typeof com.gfnOpenMenu !== 'function') return 'MENU_NOT_READY';
  com.gfnOpenMenu("FIUA006_01", {
    isHistory: true,
    param: {
      bizNo: $numberJson,
      bizNm: "",
      untySrchSeCd: "",
      startDt: "",
      endDt: ""
    }
  }, {});
  return 'OK';
})()
"@
$opened = $false
for ($attempt = 0; $attempt -lt 30 -and -not $opened; $attempt += 1) {
  Start-Sleep -Milliseconds 500
  try {
    $response = Send-Cdp $tab.webSocketDebuggerUrl ($attempt + 1) "Runtime.evaluate" @{
      expression = $script
      awaitPromise = $true
      returnByValue = $true
    }
    $opened = [string]$response.result.result.value -eq "OK"
  } catch {}
}
if (-not $opened) { throw "나라장터 사전규격 화면을 열지 못했습니다." }
