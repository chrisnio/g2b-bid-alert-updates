﻿param(
  [Parameter(Mandatory = $true)][string]$PreSpecNo,
  [switch]$Diagnostic
)

$ErrorActionPreference = "Stop"
$logPath = Join-Path $env:TEMP "g2b-prespec-open.log"

function Write-OpenLog([string]$Message) {
  "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff') $Message" |
    Add-Content -LiteralPath $logPath -Encoding UTF8 -ErrorAction SilentlyContinue
}

function Find-Browser {
  $paths = @(
    (Join-Path $env:ProgramFiles "Google\Chrome\Application\chrome.exe"),
    (Join-Path ${env:ProgramFiles(x86)} "Google\Chrome\Application\chrome.exe"),
    (Join-Path $env:ProgramFiles "Microsoft\Edge\Application\msedge.exe"),
    (Join-Path ${env:ProgramFiles(x86)} "Microsoft\Edge\Application\msedge.exe")
  )
  foreach ($path in $paths) {
    if (Test-Path -LiteralPath $path) { return $path }
  }
  throw "Chrome or Edge was not found."
}

function Send-Cdp($WebSocketUrl, [int]$Id, [string]$Method, $Params) {
  $client = [System.Net.WebSockets.ClientWebSocket]::new()
  if (-not $client.ConnectAsync([Uri]$WebSocketUrl, [Threading.CancellationToken]::None).Wait(5000)) {
    throw "CDP_CONNECT_TIMEOUT"
  }
  try {
    $payload = (@{ id = $Id; method = $Method; params = $Params } | ConvertTo-Json -Depth 20 -Compress)
    $bytes = [Text.Encoding]::UTF8.GetBytes($payload)
    $client.SendAsync([ArraySegment[byte]]::new($bytes), [System.Net.WebSockets.WebSocketMessageType]::Text, $true, [Threading.CancellationToken]::None).Wait(5000) | Out-Null
    $buffer = New-Object byte[] 4194304
    while ($true) {
      $text = ""
      do {
        $receive = $client.ReceiveAsync([ArraySegment[byte]]::new($buffer), [Threading.CancellationToken]::None)
        if (-not $receive.Wait(60000)) { throw "CDP_RECEIVE_TIMEOUT" }
        $result = $receive.Result
        $text += [Text.Encoding]::UTF8.GetString($buffer, 0, $result.Count)
      } while (-not $result.EndOfMessage)
      $message = $text | ConvertFrom-Json
      if ($message.id -eq $Id) { return $message }
    }
  } finally {
    $client.Dispose()
  }
}

$browser = Find-Browser
$port = Get-Random -Minimum 9701 -Maximum 9999
$profile = Join-Path $env:TEMP ("g2b-prespec-view-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Force -Path $profile | Out-Null

$process = Start-Process -FilePath $browser -ArgumentList @(
  "--new-window",
  "--no-first-run",
  "--disable-extensions",
  "--remote-allow-origins=*",
  "--user-data-dir=$profile",
  "--remote-debugging-port=$port",
  "https://www.g2b.go.kr/"
) -PassThru

$tab = $null
for ($attempt = 0; $attempt -lt 30 -and -not $tab; $attempt += 1) {
  Start-Sleep -Milliseconds 500
  try {
    $tabsResponse = Invoke-WebRequest -Uri "http://127.0.0.1:$port/json/list" -UseBasicParsing -TimeoutSec 3
    $tabs = ConvertFrom-Json -InputObject $tabsResponse.Content
    foreach ($candidate in $tabs) {
      if ($candidate.type -eq "page" -and $candidate.url -like "https://www.g2b.go.kr/*") {
        $tab = $candidate
        break
      }
    }
  } catch {}
}
if (-not $tab) {
  Write-OpenLog "TAB_NOT_FOUND port=$port prespec=$PreSpecNo"
  throw "Could not connect to the browser."
}
Write-OpenLog "TAB_CONNECTED port=$port tab=$($tab.id) prespec=$PreSpecNo"
Start-Sleep -Seconds 5

$numberJson = $PreSpecNo | ConvertTo-Json -Compress
$script:CdpId = 0
function Invoke-TabExpression([string]$Expression, [bool]$AwaitPromise = $false) {
  $script:CdpId += 1
  $response = Send-Cdp $tab.webSocketDebuggerUrl $script:CdpId "Runtime.evaluate" @{
    expression = $Expression
    awaitPromise = $AwaitPromise
    returnByValue = $true
  }
  if ($response.error) { throw "CDP_ERROR: $($response.error.message)" }
  if ($response.result.exceptionDetails) { throw "SCRIPT_ERROR: $($response.result.exceptionDetails.text)" }
  return $response.result.result.value
}

function Wait-TabExpression([string]$Expression, [string]$Stage, [int]$Attempts = 60) {
  for ($attempt = 0; $attempt -lt $Attempts; $attempt += 1) {
    try {
      $value = Invoke-TabExpression $Expression
      if ($value) {
        Write-OpenLog "$Stage=$value"
        return [string]$value
      }
    } catch {
      Write-OpenLog "$Stage retry=$($_.Exception.Message)"
    }
    Start-Sleep -Milliseconds 500
  }
  return ""
}

$lastResult = "SEARCH_CONTROLS_NOT_READY"
try {
  Write-OpenLog "AUTOMATION_START tab=$($tab.id)"
  $controlsReady = Wait-TabExpression @"
Boolean(
  document.querySelector('input[id$="_totBizNo"]') &&
  document.querySelector('input[id$="_btnUntyDtlSrch"],button[id$="_btnUntyDtlSrch"],a[id$="_btnUntyDtlSrch"]')
)
"@ "controls"

  if ($controlsReady) {
    $lastResult = "SEARCH_CLICK_FAILED"
    $searchResult = Invoke-TabExpression @"
(async () => {
  const target = $numberJson;
  const input = document.querySelector('input[id$="_totBizNo"]');
  const button = document.querySelector(
    'input[id$="_btnUntyDtlSrch"],button[id$="_btnUntyDtlSrch"],a[id$="_btnUntyDtlSrch"]'
  );
  if (!input || !button) return "";
  await new Promise(resolve => setTimeout(resolve, 20000));
  try {
    const component = window.`$p && `$p.getComponentById ? `$p.getComponentById(input.id) : null;
    if (component && component.setValue) component.setValue(target);
  } catch (error) {}
  input.value = target;
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
  button.click();
  await new Promise(resolve => setTimeout(resolve, 5000));
  return "SEARCH_CLICKED";
})()
"@ $true
    Write-OpenLog "search=$searchResult"

    if ($searchResult -eq "SEARCH_CLICKED") {
      $lastResult = "RESULT_NOT_FOUND"
      $moreId = Wait-TabExpression @"
(() => {
  const target = $numberJson;
  const row = Array.from(document.querySelectorAll("tr")).find(item =>
    (item.innerText || "").includes(target) && item.querySelector('a[id$="_btnOpenKonepsInfo"]')
  );
  const button = row ? row.querySelector('a[id$="_btnOpenKonepsInfo"]') : null;
  return button ? button.id : "";
})()
"@ "result"

      if ($moreId) {
        $lastResult = "MORE_CLICK_FAILED"
        $moreIdJson = $moreId | ConvertTo-Json -Compress
        Invoke-TabExpression "(() => { const e = document.getElementById($moreIdJson); if (!e) return ''; e.click(); return 'MORE_CLICKED'; })()" | Out-Null

        $lastResult = "PRESPEC_STEP_NOT_FOUND"
        $preSpecId = Wait-TabExpression @"
(() => {
  const target = $numberJson;
  const element = Array.from(document.querySelectorAll('[id$="_bfSpec"].link.blue')).find(item =>
    (item.innerText || "").includes(target)
  );
  return element ? element.id : "";
})()
"@ "prespec"

        if ($preSpecId) {
          $lastResult = "PRESPEC_CLICK_FAILED"
          $preSpecIdJson = $preSpecId | ConvertTo-Json -Compress
          Invoke-TabExpression "(() => { const e = document.getElementById($preSpecIdJson); if (!e) return ''; e.click(); return 'PRESPEC_CLICKED'; })()" | Out-Null

          $lastResult = "DETAIL_NOT_OPENED"
          $detailOpened = Wait-TabExpression @"
(() => {
  const target = $numberJson;
  const input = Array.from(document.querySelectorAll('input[id*="bfSpecWfrm_bfSpecRegNo"]')).find(item =>
    item.value === target
  );
  if (!input) return "";
  input.scrollIntoView({ block: "center" });
  return "DETAIL_OPENED";
})()
"@ "detail"
          if ($detailOpened) { $lastResult = $detailOpened }
        }
      }
    }
  }

  Write-OpenLog "AUTOMATION_RESULT result=$lastResult"
  if ($lastResult -ne "DETAIL_OPENED") {
    try {
      $pageState = Invoke-TabExpression @"
JSON.stringify({
  url: location.href,
  bizNo: document.querySelector('input[id$="_totBizNo"]')?.value || "",
  buttons: Array.from(document.querySelectorAll('a,button,input[type="button"]'))
    .map(e => ({ id: e.id || "", text: (e.innerText || e.value || e.title || "").trim() }))
    .filter(e => e.text.includes("검색") || e.id.toLowerCase().includes("search"))
    .slice(0, 30),
  text: (document.body.innerText || "").slice(0, 1200)
})
"@
      Write-OpenLog ("PAGE_STATE " + [string]$pageState)
    } catch {
      Write-OpenLog "PAGE_STATE_ERROR $($_.Exception.Message)"
    }
  }
} catch {
  $lastResult = "BROWSER_CONTROL_FAILED"
  Write-OpenLog "AUTOMATION_ERROR $($_.Exception.ToString())"
  if ($Diagnostic) { Write-Host "control-error=$($_.Exception.Message)" }
}

$opened = $lastResult -eq "DETAIL_OPENED"
if (-not $opened) {
  Write-OpenLog "OPEN_FAILED result=$lastResult"
  if ($Diagnostic) {
    Write-Host "failed=$lastResult"
  }
  try {
    if ($process -and -not $process.HasExited) {
      Start-Process -FilePath "taskkill.exe" -WindowStyle Hidden -Wait -ArgumentList @("/PID", [string]$process.Id, "/T", "/F") | Out-Null
    }
  } catch {}
  Remove-Item -LiteralPath $profile -Recurse -Force -ErrorAction SilentlyContinue
  if ($Diagnostic) {
    exit 1
  }
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.MessageBox]::Show(
    "나라장터 사전규격 상세 화면을 열지 못했습니다.`n`n사전규격번호: $PreSpecNo`n상태: $lastResult",
    "나라장터 사전규격 열기",
    "OK",
    "Warning"
  ) | Out-Null
  exit 1
}
Write-OpenLog "OPEN_SUCCESS prespec=$PreSpecNo"
