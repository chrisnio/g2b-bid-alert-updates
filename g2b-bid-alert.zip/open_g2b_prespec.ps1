﻿param(
  [Parameter(Mandatory = $true)][string]$PreSpecNo,
  [switch]$Diagnostic
)

$ErrorActionPreference = "Stop"

function Find-Browser {
  $paths = @(
    (Join-Path $env:ProgramFiles "Google\Chrome\Application\chrome.exe"),
    (Join-Path ${env:ProgramFiles(x86)} "Google\Chrome\Application\chrome.exe"),
    (Join-Path $env:ProgramFiles "Microsoft\Edge\Application\msedge.exe"),
    (Join-Path ${env:ProgramFiles(x86)} "Microsoft\Edge\Application\msedge.exe")
  )
  foreach ($path in $paths) {
    if (Test-Path -LiteralPath $path) { return $path }
  }
  throw "Chrome or Edge was not found."
}

function Send-Cdp($WebSocketUrl, [int]$Id, [string]$Method, $Params) {
  $client = [System.Net.WebSockets.ClientWebSocket]::new()
  if (-not $client.ConnectAsync([Uri]$WebSocketUrl, [Threading.CancellationToken]::None).Wait(5000)) {
    throw "CDP_CONNECT_TIMEOUT"
  }
  try {
    $payload = (@{ id = $Id; method = $Method; params = $Params } | ConvertTo-Json -Depth 20 -Compress)
    $bytes = [Text.Encoding]::UTF8.GetBytes($payload)
    $client.SendAsync([ArraySegment[byte]]::new($bytes), [System.Net.WebSockets.WebSocketMessageType]::Text, $true, [Threading.CancellationToken]::None).Wait(5000) | Out-Null
    $buffer = New-Object byte[] 4194304
    while ($true) {
      $text = ""
      do {
        $receive = $client.ReceiveAsync([ArraySegment[byte]]::new($buffer), [Threading.CancellationToken]::None)
        if (-not $receive.Wait(60000)) { throw "CDP_RECEIVE_TIMEOUT" }
        $result = $receive.Result
        $text += [Text.Encoding]::UTF8.GetString($buffer, 0, $result.Count)
      } while (-not $result.EndOfMessage)
      $message = $text | ConvertFrom-Json
      if ($message.id -eq $Id) { return $message }
    }
  } finally {
    $client.Dispose()
  }
}

$browser = Find-Browser
$port = Get-Random -Minimum 9701 -Maximum 9999
$profile = Join-Path $env:TEMP ("g2b-prespec-view-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Force -Path $profile | Out-Null

$process = Start-Process -FilePath $browser -ArgumentList @(
  "--new-window",
  "--no-first-run",
  "--disable-extensions",
  "--user-data-dir=$profile",
  "--remote-debugging-port=$port",
  "about:blank"
) -PassThru

$tab = $null
for ($attempt = 0; $attempt -lt 30 -and -not $tab; $attempt += 1) {
  Start-Sleep -Milliseconds 500
  try {
    $tab = Invoke-RestMethod -Uri "http://127.0.0.1:$port/json/new?https://www.g2b.go.kr/" -Method Put -TimeoutSec 3
  } catch {}
}
if (-not $tab) { throw "Could not connect to the browser." }

$numberJson = $PreSpecNo | ConvertTo-Json -Compress
Start-Sleep -Seconds 6
try {
  $liveTabs = @(Invoke-RestMethod -Uri "http://127.0.0.1:$port/json/list" -TimeoutSec 5)
  $liveTab = $liveTabs |
    Where-Object { $_.type -eq "page" -and $_.url -like "https://www.g2b.go.kr/*" } |
    Select-Object -First 1
  if ($liveTab) { $tab = $liveTab }
  if ($Diagnostic) {
    Write-Host ("tab=" + ($liveTabs | ForEach-Object { "$($_.id):$($_.url)" } | Out-String).Trim())
  }
} catch {
  if ($Diagnostic) { Write-Host "tab-refresh-error=$($_.Exception.Message)" }
}
$automationExpression = @"
(async () => {
  const target = $numberJson;
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const waitFor = async (finder, attempts = 40) => {
    for (let i = 0; i < attempts; i++) {
      const found = finder();
      if (found) return found;
      await sleep(500);
    }
    return null;
  };

  const menu = await waitFor(() => window.com && typeof com.gfnOpenMenu === "function" ? com : null);
  if (!menu) return "MENU_NOT_READY";

  com.gfnOpenMenu("FIUA006_01", {
    isHistory: true,
    param: { bizNo: target, bizNm: "", untySrchSeCd: "", startDt: "", endDt: "" }
  }, {});

  const moreButton = await waitFor(() => {
    const row = Array.from(document.querySelectorAll("tr")).find(item =>
      (item.innerText || "").includes(target) && item.querySelector('a[id$="_btnOpenKonepsInfo"]')
    );
    return row ? row.querySelector('a[id$="_btnOpenKonepsInfo"]') : null;
  });
  if (!moreButton) return "RESULT_NOT_FOUND";
  moreButton.click();

  const preSpecStep = await waitFor(() =>
    Array.from(document.querySelectorAll('[id$="_bfSpec"].link.blue')).find(item =>
      (item.innerText || "").includes(target)
    )
  );
  if (!preSpecStep) return "PRESPEC_STEP_NOT_FOUND";
  preSpecStep.click();

  const detailInput = await waitFor(() =>
    Array.from(document.querySelectorAll('input[id*="bfSpecWfrm_bfSpecRegNo"]')).find(item =>
      item.value === target
    )
  );
  if (!detailInput) return "DETAIL_NOT_OPENED";
  detailInput.scrollIntoView({ block: "center" });
  return "DETAIL_OPENED";
})()
"@

$lastResult = "AUTOMATION_FAILED"
try {
  $response = Send-Cdp $tab.webSocketDebuggerUrl 1 "Runtime.evaluate" @{
    expression = $automationExpression
    awaitPromise = $true
    returnByValue = $true
  }
  if ($response.result.exceptionDetails) {
    $lastResult = "SCRIPT_ERROR"
  } elseif ($response.result.result.value) {
    $lastResult = [string]$response.result.result.value
  }
} catch {
  $lastResult = "BROWSER_CONTROL_FAILED"
  if ($Diagnostic) { Write-Host "control-error=$($_.Exception.Message)" }
}

$opened = $lastResult -eq "DETAIL_OPENED"
if (-not $opened) {
  if ($Diagnostic) {
    Write-Host "failed=$lastResult"
  }
  try {
    if ($process -and -not $process.HasExited) {
      Start-Process -FilePath "taskkill.exe" -WindowStyle Hidden -Wait -ArgumentList @("/PID", [string]$process.Id, "/T", "/F") | Out-Null
    }
  } catch {}
  Remove-Item -LiteralPath $profile -Recurse -Force -ErrorAction SilentlyContinue
  if ($Diagnostic) {
    exit 1
  }
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.MessageBox]::Show(
    "나라장터 사전규격 상세 화면을 열지 못했습니다.`n`n사전규격번호: $PreSpecNo`n상태: $lastResult",
    "나라장터 사전규격 열기",
    "OK",
    "Warning"
  ) | Out-Null
  exit 1
}
